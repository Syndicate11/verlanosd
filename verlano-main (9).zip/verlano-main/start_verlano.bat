@echo off
title Verlano - Mini App + Cloudflare Tunnel

echo ===================================================
echo   VERLANO - Server + Cloudflare Tunnel Launcher
echo ===================================================
echo.

if exist node_modules goto deps_ok
echo [1/4] Installing npm dependencies...
call npm install --legacy-peer-deps
if errorlevel 1 goto err_exit
goto deps_done

:deps_ok
echo [1/4] Dependencies already installed.

:deps_done
if exist .env goto env_ok
if exist ..\verlano.env goto env_parent
echo [2/4] Creating .env from .env.example...
copy .env.example .env > nul
echo NOTE: Fill TELEGRAM_BOT_TOKEN and ADMIN_PASSWORD in .env for Telegram mode.
goto env_done

:env_parent
echo [2/4] Restoring .env from ..\verlano.env...
copy ..\verlano.env .env > nul
goto env_done

:env_ok
echo [2/4] .env file found.

:env_done
echo [3/4] Building Verlano frontend...
call npm run build
if errorlevel 1 goto err_exit

echo [4/4] Starting Express server on http://localhost:3000...
start "Verlano Server" cmd /k "set NODE_ENV=production && npx tsx server.ts"

timeout /t 3 /nobreak > nul

where cloudflared >nul 2>nul
if errorlevel 1 goto no_cloudflared

echo.
echo Starting Cloudflare Tunnel (HTTP/2 over TCP)...
echo Copy the https://*.trycloudflare.com URL below and paste it into @BotFather.
echo.
cloudflared tunnel --protocol http2 --url http://localhost:3000
if errorlevel 1 goto tunnel_err
pause
exit /b 0

:no_cloudflared
if exist cloudflared.exe goto local_cloudflared
echo.
echo [!] cloudflared was not found in PATH or project folder.
echo Install via: winget install --id Cloudflare.cloudflared
echo Or use built-in SSH tunnel: ssh -R 80:localhost:3000 nokey@localhost.run
pause
exit /b 1

:local_cloudflared
echo.
echo Starting local cloudflared.exe (HTTP/2 over TCP)...
echo Copy the https://*.trycloudflare.com URL below and paste it into @BotFather.
echo.
cloudflared.exe tunnel --protocol http2 --url http://localhost:3000
if errorlevel 1 goto tunnel_err
pause
exit /b 0

:tunnel_err
echo.
echo [!] Cloudflare Tunnel failed (DNS SRV lookup blocked by FakeIP/TUN or ISP).
echo Fix: disable FakeIP/tun_incy DNS or run fallback SSH tunnel:
echo   ssh -R 80:localhost:3000 nokey@localhost.run
pause
exit /b 1

:err_exit
echo.
echo [!] Build or install failed. Check the error above.
pause
exit /b 1
