#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${1:-}"
if [ -z "$DOMAIN" ]; then
  echo "Использование: bash deploy_vps.sh yourdomain.ru"
  exit 1
fi

echo "=== [1/5] Установка Node.js 22 и Caddy ==="
sudo apt-get update -y
sudo apt-get install -y curl gnupg ca-certificates debian-keyring debian-archive-keyring apt-transport-https

if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

if ! command -v caddy >/dev/null 2>&1; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg --yes
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  sudo apt-get update -y
  sudo apt-get install -y caddy
fi

if ! command -v pm2 >/dev/null 2>&1; then
  sudo npm install -g pm2
fi

echo "=== [2/5] Проверка .env ==="
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Создан .env из .env.example. Не забудьте заполнить его и выполнить: pm2 restart verlano"
fi

echo "=== [3/5] Установка зависимостей и сборка Verlano ==="
npm install --legacy-peer-deps
npm run build

echo "=== [4/5] Запуск сервера Verlano через PM2 ==="
pm2 delete verlano >/dev/null 2>&1 || true
NODE_ENV=production pm2 start ./node_modules/.bin/tsx --name verlano -- server.ts
pm2 save

echo "=== [5/5] Настройка HTTPS (Let's Encrypt) через Caddy для $DOMAIN ==="
if command -v ufw >/dev/null 2>&1 && sudo ufw status | grep -q "Status: active"; then
  sudo ufw allow 80/tcp >/dev/null 2>&1 || true
  sudo ufw allow 443/tcp >/dev/null 2>&1 || true
fi

sudo tee /etc/caddy/Caddyfile >/dev/null <<EOF
$DOMAIN {
    reverse_proxy 127.0.0.1:3000
}
EOF

sudo systemctl enable caddy
sudo systemctl restart caddy

echo ""
echo "Готово! Verlano доступен по адресу: https://$DOMAIN"
echo "Проверьте статус: pm2 status && pm2 logs verlano --lines 20"
