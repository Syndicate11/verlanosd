import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs';
import express from 'express';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { getDb, getOrCreateProfile, saveDb } from './server/db.ts';
import {
  checkTelegramChannelMembership,
  notifyAdminsOfOrder,
  notifyCustomerOrderStatus,
  startTelegramBotPolling,
  verifyTelegramInitData,
} from './server/telegram.ts';
import type {
  CategoryKey,
  Order,
  OrderStatus,
  Product,
  ProductSizeStock,
} from './src/types/store.ts';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

const STATUS_LABELS: Record<OrderStatus, string> = {
  new: 'Новый',
  confirmed: 'Подтверждён',
  packing: 'В сборке',
  shipped: 'Отправлен',
  delivered: 'Доставлен',
};

function sanitizeString(value: unknown, maxLen = 300): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().slice(0, maxLen);
}

function isSafeImageUrl(url: string): boolean {
  if (!url) {
    return true;
  }
  if (url.startsWith('/src/assets/images/') && !url.includes('..')) {
    return true;
  }
  if (/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(url) && url.length <= 2_000_000) {
    return true;
  }
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function verifyPasswordHash(password: string, salt: string, expectedHex: string): boolean {
  const actual = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function safeCompareStrings(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf-8');
  const bufB = Buffer.from(b, 'utf-8');
  if (bufA.length !== bufB.length) {
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

function signAdminToken(adminId: string): string {
  const payload = Buffer.from(
    JSON.stringify({
      adminId,
      exp: Date.now() + 1000 * 60 * 60 * 12,
    }),
    'utf-8'
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyAdminToken(token: string): { adminId: string } | null {
  const parts = token.split('.');
  if (parts.length !== 2) {
    return null;
  }
  const [payload, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  if (!safeCompareStrings(sig, expectedSig)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8')) as {
      adminId?: string;
      exp?: number;
    };
    if (!parsed.adminId || !parsed.exp || Date.now() > parsed.exp) {
      return null;
    }
    return { adminId: parsed.adminId };
  } catch {
    return null;
  }
}

function getAllowedAdminIds(): string[] {
  const envIds = (process.env.ADMIN_TELEGRAM_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const db = getDb();
  if (db.adminAuth?.adminId && !envIds.includes(db.adminAuth.adminId)) {
    envIds.push(db.adminAuth.adminId);
  }
  return envIds;
}

interface ResolvedIdentity {
  userId: string;
  isTelegramVerified: boolean;
  firstName?: string;
  lastName?: string;
  username?: string;
  photoUrl?: string;
}

function resolveCallerIdentity(req: express.Request): ResolvedIdentity {
  const botToken = process.env.TELEGRAM_BOT_TOKEN || '';
  const initData = sanitizeString(req.header('x-telegram-init-data'), 4096);
  if (initData && botToken) {
    const verified = verifyTelegramInitData(initData, botToken);
    if (verified) {
      return {
        userId: verified.id,
        isTelegramVerified: true,
        firstName: verified.firstName,
        lastName: verified.lastName,
        username: verified.username,
        photoUrl: verified.photoUrl,
      };
    }
  }

  const demoUserId = sanitizeString(req.header('x-demo-user-id'), 64);
  const cleanDemoId = /^[A-Za-z0-9_-]{4,64}$/.test(demoUserId) ? demoUserId : 'demo_guest_01';
  return {
    userId: cleanDemoId,
    isTelegramVerified: false,
  };
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction): void {
  const authHeader = req.header('authorization') || '';
  if (!authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Требуется авторизация администратора' });
    return;
  }
  const token = authHeader.slice(7).trim();
  const verified = verifyAdminToken(token);
  if (!verified) {
    res.status(401).json({ error: 'Сессия администратора недействительна или истекла' });
    return;
  }
  (req as express.Request & { adminId?: string }).adminId = verified.adminId;
  next();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '3mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, brand: 'Verlano' });
  });

  app.get('/api/bootstrap', async (req, res) => {
    const identity = resolveCallerIdentity(req);
    const db = getDb();
    const profile = getOrCreateProfile(identity.userId, {
      nickname: identity.username || undefined,
      firstName: identity.firstName || undefined,
      lastName: identity.lastName || undefined,
      avatarUrl: identity.photoUrl || undefined,
    });

    const botToken = process.env.TELEGRAM_BOT_TOKEN || '';
    const botConfigured = Boolean(botToken);
    let subscribed = profile.demoSubscribed;
    let mode: 'telegram' | 'demo' = 'demo';

    if (botConfigured && identity.isTelegramVerified) {
      mode = 'telegram';
      const check = await checkTelegramChannelMembership(
        botToken,
        db.settings.channelUsername,
        identity.userId
      );
      subscribed = check.ok ? check.subscribed : false;
    }

    const userOrders = db.orders
      .filter((o) => o.userId === identity.userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    const publicPromos = db.promoCodes.filter((p) => p.active && p.isPublic);

    res.json({
      profile,
      orders: userOrders,
      products: db.products,
      publicPromos,
      newsPosts: db.newsPosts,
      settings: db.settings,
      subscription: {
        subscribed,
        mode,
        channelUsername: db.settings.channelUsername,
        channelUrl: db.settings.channelUrl,
        botConfigured,
      },
    });
  });

  app.post('/api/telegram/check-subscription', async (req, res) => {
    const identity = resolveCallerIdentity(req);
    const db = getDb();
    const profile = getOrCreateProfile(identity.userId);
    const botToken = process.env.TELEGRAM_BOT_TOKEN || '';

    if (botToken && identity.isTelegramVerified) {
      const check = await checkTelegramChannelMembership(
        botToken,
        db.settings.channelUsername,
        identity.userId
      );
      res.json({
        subscribed: check.ok ? check.subscribed : false,
        mode: 'telegram',
        channelUsername: db.settings.channelUsername,
        channelUrl: db.settings.channelUrl,
        botConfigured: true,
        message: check.subscribed
          ? 'Подписка на канал подтверждена'
          : check.error || 'Подпишитесь на канал новостей и нажмите «Проверить подписку»',
      });
      return;
    }

    res.json({
      subscribed: profile.demoSubscribed,
      mode: 'demo',
      channelUsername: db.settings.channelUsername,
      channelUrl: db.settings.channelUrl,
      botConfigured: Boolean(botToken),
      message: profile.demoSubscribed
        ? 'Подписка подтверждена в браузерном предпросмотре'
        : 'Для проверки через Bot API откройте приложение в Telegram или активируйте демо-подписку.',
    });
  });

  app.post('/api/telegram/demo-subscribe', (req, res) => {
    const identity = resolveCallerIdentity(req);
    const subscribed = Boolean((req.body as { subscribed?: unknown })?.subscribed ?? true);
    getOrCreateProfile(identity.userId);
    saveDb((state) => {
      state.profiles[identity.userId].demoSubscribed = subscribed;
      state.profiles[identity.userId].updatedAt = new Date().toISOString();
    });
    const db = getDb();
    res.json({
      subscribed,
      mode: 'demo',
      channelUsername: db.settings.channelUsername,
      channelUrl: db.settings.channelUrl,
      botConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN),
    });
  });

  app.put('/api/profile', (req, res) => {
    const identity = resolveCallerIdentity(req);
    const body = (req.body || {}) as Record<string, unknown>;
    const existing = getOrCreateProfile(identity.userId);

    const avatarUrl =
      body.avatarUrl !== undefined ? sanitizeString(body.avatarUrl, 650_000) : existing.avatarUrl;
    if (!isSafeImageUrl(avatarUrl)) {
      res.status(400).json({ error: 'Недопустимый формат изображения аватара' });
      return;
    }

    const updated = {
      ...existing,
      nickname: sanitizeString(body.nickname, 40) || existing.nickname,
      firstName: sanitizeString(body.firstName, 60),
      lastName: sanitizeString(body.lastName, 60),
      phone: sanitizeString(body.phone, 32),
      address: sanitizeString(body.address, 240),
      deliveryNote: sanitizeString(body.deliveryNote, 240),
      avatarUrl,
      updatedAt: new Date().toISOString(),
    };

    saveDb((state) => {
      state.profiles[identity.userId] = updated;
    });

    res.json({ profile: updated });
  });

  app.post('/api/promocodes/validate', (req, res) => {
    const rawCode = sanitizeString((req.body as { code?: unknown })?.code, 40).toUpperCase();
    const subtotal = Number((req.body as { subtotal?: unknown })?.subtotal) || 0;
    if (!rawCode) {
      res.status(400).json({ error: 'Введите промокод' });
      return;
    }
    const db = getDb();
    const promo = db.promoCodes.find((p) => p.code.toUpperCase() === rawCode && p.active);
    if (!promo) {
      res.status(404).json({ error: 'Промокод не найден или отключён' });
      return;
    }
    if (subtotal > 0 && subtotal < promo.minOrderAmount) {
      res.status(400).json({
        error: `Минимальная сумма заказа для ${promo.code}: ${promo.minOrderAmount} ₽`,
      });
      return;
    }
    res.json({ promo });
  });

  app.post('/api/orders', async (req, res) => {
    const identity = resolveCallerIdentity(req);
    const body = (req.body || {}) as {
      items?: Array<{ productId?: unknown; size?: unknown; quantity?: unknown }>;
      promoCode?: unknown;
      customer?: {
        nickname?: unknown;
        firstName?: unknown;
        lastName?: unknown;
        phone?: unknown;
        address?: unknown;
        deliveryNote?: unknown;
      };
    };

    if (!Array.isArray(body.items) || body.items.length === 0) {
      res.status(400).json({ error: 'Корзина пуста' });
      return;
    }

    const firstName = sanitizeString(body.customer?.firstName, 60);
    const lastName = sanitizeString(body.customer?.lastName, 60);
    const phone = sanitizeString(body.customer?.phone, 32);
    const address = sanitizeString(body.customer?.address, 240);
    const nickname = sanitizeString(body.customer?.nickname, 40) || 'client';
    const deliveryNote = sanitizeString(body.customer?.deliveryNote, 240);

    if (!firstName || !phone || !address) {
      res.status(400).json({ error: 'Укажите имя, телефон и адрес доставки' });
      return;
    }

    const db = getDb();
    const validSizes = new Set(['S', 'M', 'L', 'XL']);
    const resolvedItems: Order['items'] = [];
    let subtotalAmount = 0;

    for (const rawItem of body.items) {
      const productId = sanitizeString(rawItem.productId, 80);
      const size = sanitizeString(rawItem.size, 4) as 'S' | 'M' | 'L' | 'XL';
      const quantity = Math.floor(Number(rawItem.quantity));

      if (!productId || !validSizes.has(size) || !Number.isFinite(quantity) || quantity < 1 || quantity > 50) {
        res.status(400).json({ error: 'Некорректные параметры товара в заказе' });
        return;
      }

      const product = db.products.find((p) => p.id === productId);
      if (!product) {
        res.status(404).json({ error: 'Один из товаров в корзине больше не доступен' });
        return;
      }

      const sizeEntry = product.sizes.find((s) => s.size === size);
      if (!sizeEntry || sizeEntry.stock < quantity) {
        res.status(400).json({
          error: `Недостаточно остатка для ${product.name} (${size})`,
        });
        return;
      }

      subtotalAmount += product.price * quantity;
      resolvedItems.push({
        productId: product.id,
        name: product.name,
        imageUrl: product.imageUrl,
        size,
        quantity,
        unitPrice: product.price,
      });
    }

    let appliedPromoCode: string | null = null;
    let discountAmount = 0;
    const requestedPromo = sanitizeString(body.promoCode, 40).toUpperCase();
    if (requestedPromo) {
      const promo = db.promoCodes.find((p) => p.code.toUpperCase() === requestedPromo && p.active);
      if (promo && subtotalAmount >= promo.minOrderAmount) {
        appliedPromoCode = promo.code;
        discountAmount = Math.round((subtotalAmount * promo.discountPercent) / 100);
      }
    }

    const totalAmount = Math.max(0, subtotalAmount - discountAmount);
    const orderNumber = `VRL-${String(1041 + db.orders.length)}`;
    const order: Order = {
      id: `ord_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
      orderNumber,
      userId: identity.userId,
      items: resolvedItems,
      promoCode: appliedPromoCode,
      subtotalAmount,
      discountAmount,
      totalAmount,
      customerSnapshot: {
        nickname,
        firstName,
        lastName,
        phone,
        address,
        deliveryNote,
      },
      status: 'new',
      createdAt: new Date().toISOString(),
    };

    getOrCreateProfile(identity.userId);
    saveDb((state) => {
      for (const item of resolvedItems) {
        const product = state.products.find((p) => p.id === item.productId);
        const sizeEntry = product?.sizes.find((s) => s.size === item.size);
        if (sizeEntry) {
          sizeEntry.stock = Math.max(0, sizeEntry.stock - item.quantity);
        }
      }
      state.orders.unshift(order);
    });

    const botToken = process.env.TELEGRAM_BOT_TOKEN || '';
    if (botToken) {
      void notifyAdminsOfOrder(botToken, getAllowedAdminIds(), order);
    }

    res.status(201).json({ order });
  });

  // --- Admin Auth & Management ---

  app.get('/api/admin/status', (_req, res) => {
    const db = getDb();
    res.json({
      envConfigured: Boolean(process.env.ADMIN_PASSWORD),
      claimed: Boolean(db.adminAuth),
      allowedIdsConfigured: Boolean(process.env.ADMIN_TELEGRAM_IDS || db.adminAuth?.adminId),
    });
  });

  app.post('/api/admin/setup', (req, res) => {
    if (process.env.ADMIN_PASSWORD) {
      res.status(409).json({ error: 'Пароль администратора уже задан в переменных окружения' });
      return;
    }
    const db = getDb();
    if (db.adminAuth) {
      res.status(409).json({ error: 'Администратор уже активирован. Используйте форму входа.' });
      return;
    }

    const body = (req.body || {}) as { adminId?: unknown; password?: unknown };
    const adminId = sanitizeString(body.adminId, 64);
    const password = typeof body.password === 'string' ? body.password : '';

    if (!adminId || password.length < 6) {
      res.status(400).json({ error: 'Укажите Telegram ID и пароль (минимум 6 символов)' });
      return;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, salt);

    saveDb((state) => {
      state.adminAuth = {
        adminId,
        passwordSalt: salt,
        passwordHash,
        claimedAt: new Date().toISOString(),
      };
    });

    const token = signAdminToken(adminId);
    res.status(201).json({ token, adminId });
  });

  app.post('/api/admin/login', (req, res) => {
    const body = (req.body || {}) as { adminId?: unknown; password?: unknown };
    const adminId = sanitizeString(body.adminId, 64);
    const password = typeof body.password === 'string' ? body.password : '';

    if (!adminId || !password) {
      res.status(400).json({ error: 'Введите Telegram ID администратора и пароль' });
      return;
    }

    const envPassword = process.env.ADMIN_PASSWORD || '';
    const allowedIds = getAllowedAdminIds();

    if (envPassword) {
      if (allowedIds.length > 0 && !allowedIds.includes(adminId)) {
        res.status(403).json({ error: 'Этот Telegram ID не входит в список администраторов' });
        return;
      }
      if (!safeCompareStrings(password, envPassword)) {
        res.status(401).json({ error: 'Неверный пароль администратора' });
        return;
      }
      res.json({ token: signAdminToken(adminId), adminId });
      return;
    }

    const db = getDb();
    if (!db.adminAuth) {
      res.status(400).json({ error: 'Администратор ещё не активирован' });
      return;
    }
    if (!safeCompareStrings(adminId, db.adminAuth.adminId)) {
      res.status(403).json({ error: 'Неверный Telegram ID администратора' });
      return;
    }
    if (!verifyPasswordHash(password, db.adminAuth.passwordSalt, db.adminAuth.passwordHash)) {
      res.status(401).json({ error: 'Неверный пароль администратора' });
      return;
    }

    res.json({ token: signAdminToken(adminId), adminId });
  });

  app.get('/api/admin/overview', requireAdmin, (_req, res) => {
    const db = getDb();
    res.json({
      orders: db.orders,
      products: db.products,
      promoCodes: db.promoCodes,
      settings: db.settings,
      botConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN),
      channelEnvConfigured: Boolean(process.env.TELEGRAM_CHANNEL_ID),
    });
  });

  app.patch('/api/admin/orders/:orderId/status', requireAdmin, (req, res) => {
    const orderId = sanitizeString(req.params.orderId, 80);
    const status = sanitizeString((req.body as { status?: unknown })?.status, 20) as OrderStatus;
    if (!Object.prototype.hasOwnProperty.call(STATUS_LABELS, status)) {
      res.status(400).json({ error: 'Некорректный статус заказа' });
      return;
    }

    const db = getDb();
    const target = db.orders.find((o) => o.id === orderId);
    if (!target) {
      res.status(404).json({ error: 'Заказ не найден' });
      return;
    }

    saveDb((state) => {
      const order = state.orders.find((o) => o.id === orderId);
      if (order) {
        order.status = status;
      }
    });

    const botToken = process.env.TELEGRAM_BOT_TOKEN || '';
    if (botToken) {
      void notifyCustomerOrderStatus(botToken, target.userId, target.orderNumber, STATUS_LABELS[status]);
    }

    res.json({ ok: true, status });
  });

  app.post('/api/admin/products', requireAdmin, (req, res) => {
    const body = (req.body || {}) as {
      category?: unknown;
      name?: unknown;
      subtitle?: unknown;
      description?: unknown;
      material?: unknown;
      fit?: unknown;
      price?: unknown;
      imageUrl?: unknown;
      sizes?: Array<{ size?: unknown; stock?: unknown }>;
    };

    const category = sanitizeString(body.category, 20) as CategoryKey;
    if (!['tshirts', 'pants', 'ziphoodies'].includes(category)) {
      res.status(400).json({ error: 'Выберите категорию: tshirts, pants или ziphoodies' });
      return;
    }

    const name = sanitizeString(body.name, 100);
    const subtitle = sanitizeString(body.subtitle, 120) || 'Минималистичная линия Verlano';
    const description = sanitizeString(body.description, 800) || 'Лимитированная позиция коллекции Verlano.';
    const material = sanitizeString(body.material, 120) || '100% хлопок премиум-плотности';
    const fit = sanitizeString(body.fit, 60) || 'Relaxed Fit';
    const price = Math.round(Number(body.price));
    const imageUrl = sanitizeString(body.imageUrl, 2_000_000);

    if (!name || !Number.isFinite(price) || price <= 0) {
      res.status(400).json({ error: 'Укажите название и корректную цену товара' });
      return;
    }
    if (!isSafeImageUrl(imageUrl)) {
      res.status(400).json({ error: 'Недопустимый URL изображения' });
      return;
    }

    const defaultImages: Record<CategoryKey, string> = {
      tshirts: '/src/assets/images/verlano_tee_heavy_1795540088982.jpg',
      pants: '/src/assets/images/verlano_pants_cargo_1795540090502.jpg',
      ziphoodies: '/src/assets/images/verlano_zip_obsidian_1795540091733.jpg',
    };

    const parsedSizes: ProductSizeStock[] = (['S', 'M', 'L', 'XL'] as const).map((sz) => {
      const match = Array.isArray(body.sizes) ? body.sizes.find((s) => s.size === sz) : undefined;
      const stock = match ? Math.max(0, Math.floor(Number(match.stock) || 0)) : 5;
      return { size: sz, stock };
    });

    const product: Product = {
      id: `verlano-${category}-${Date.now().toString(36)}`,
      category,
      name,
      subtitle,
      description,
      material,
      fit,
      price,
      imageUrl: imageUrl || defaultImages[category],
      sizes: parsedSizes,
      featured: false,
      createdAt: new Date().toISOString(),
    };

    saveDb((state) => {
      state.products.unshift(product);
    });

    res.status(201).json({ product });
  });

  app.put('/api/admin/products/:productId', requireAdmin, (req, res) => {
    const productId = sanitizeString(req.params.productId, 80);
    const body = (req.body || {}) as {
      category?: unknown;
      name?: unknown;
      subtitle?: unknown;
      description?: unknown;
      material?: unknown;
      fit?: unknown;
      price?: unknown;
      imageUrl?: unknown;
      sizes?: Array<{ size?: unknown; stock?: unknown }>;
    };

    const db = getDb();
    const existing = db.products.find((p) => p.id === productId);
    if (!existing) {
      res.status(404).json({ error: 'Товар не найден' });
      return;
    }

    const nextCategory = sanitizeString(body.category, 20) as CategoryKey;
    if (nextCategory && !['tshirts', 'pants', 'ziphoodies'].includes(nextCategory)) {
      res.status(400).json({ error: 'Недопустимая категория' });
      return;
    }

    const nextName = sanitizeString(body.name, 100);
    const nextSubtitle = sanitizeString(body.subtitle, 120);
    const nextDescription = sanitizeString(body.description, 800);
    const nextMaterial = sanitizeString(body.material, 120);
    const nextFit = sanitizeString(body.fit, 60);
    const nextPrice = body.price !== undefined ? Math.round(Number(body.price)) : existing.price;
    const nextImageUrl = body.imageUrl !== undefined ? sanitizeString(body.imageUrl, 2_000_000) : existing.imageUrl;

    if (!Number.isFinite(nextPrice) || nextPrice <= 0) {
      res.status(400).json({ error: 'Укажите корректную цену товара' });
      return;
    }
    if (nextImageUrl && !isSafeImageUrl(nextImageUrl)) {
      res.status(400).json({ error: 'Недопустимое изображение' });
      return;
    }

    let updatedProduct: Product | null = null;
    saveDb((state) => {
      const target = state.products.find((p) => p.id === productId);
      if (!target) return;
      if (nextCategory) target.category = nextCategory;
      if (nextName) target.name = nextName;
      if (nextSubtitle) target.subtitle = nextSubtitle;
      if (nextDescription) target.description = nextDescription;
      if (nextMaterial) target.material = nextMaterial;
      if (nextFit) target.fit = nextFit;
      target.price = nextPrice;
      if (nextImageUrl) target.imageUrl = nextImageUrl;
      if (Array.isArray(body.sizes)) {
        target.sizes = (['S', 'M', 'L', 'XL'] as const).map((sz) => {
          const match = body.sizes?.find((s) => s.size === sz);
          const prev = target.sizes.find((s) => s.size === sz)?.stock ?? 0;
          return {
            size: sz,
            stock: match ? Math.max(0, Math.floor(Number(match.stock) || 0)) : prev,
          };
        });
      }
      updatedProduct = target;
    });

    res.json({ product: updatedProduct });
  });

  app.delete('/api/admin/products/:productId', requireAdmin, (req, res) => {
    const productId = sanitizeString(req.params.productId, 80);
    saveDb((state) => {
      state.products = state.products.filter((p) => p.id !== productId);
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/promocodes', requireAdmin, (req, res) => {
    const body = (req.body || {}) as {
      code?: unknown;
      discountPercent?: unknown;
      minOrderAmount?: unknown;
      isPublic?: unknown;
      description?: unknown;
    };

    const code = sanitizeString(body.code, 32).toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    const discountPercent = Math.round(Number(body.discountPercent));
    const minOrderAmount = Math.max(0, Math.round(Number(body.minOrderAmount) || 0));
    const isPublic = Boolean(body.isPublic);
    const description = sanitizeString(body.description, 180) || `Скидка ${discountPercent}% на заказ`;

    if (!code || !Number.isFinite(discountPercent) || discountPercent < 1 || discountPercent > 90) {
      res.status(400).json({ error: 'Укажите код (латиница/цифры) и скидку от 1% до 90%' });
      return;
    }

    const db = getDb();
    if (db.promoCodes.some((p) => p.code.toUpperCase() === code)) {
      res.status(409).json({ error: 'Такой промокод уже существует' });
      return;
    }

    const promo = {
      id: `promo-${Date.now().toString(36)}`,
      code,
      discountPercent,
      minOrderAmount,
      isPublic,
      active: true,
      description,
      createdAt: new Date().toISOString(),
    };

    saveDb((state) => {
      state.promoCodes.unshift(promo);
    });

    res.status(201).json({ promo });
  });

  app.patch('/api/admin/promocodes/:promoId', requireAdmin, (req, res) => {
    const promoId = sanitizeString(req.params.promoId, 80);
    const body = (req.body || {}) as { active?: unknown; isPublic?: unknown };
    saveDb((state) => {
      const promo = state.promoCodes.find((p) => p.id === promoId);
      if (promo) {
        if (typeof body.active === 'boolean') {
          promo.active = body.active;
        }
        if (typeof body.isPublic === 'boolean') {
          promo.isPublic = body.isPublic;
        }
      }
    });
    res.json({ ok: true });
  });

  app.delete('/api/admin/promocodes/:promoId', requireAdmin, (req, res) => {
    const promoId = sanitizeString(req.params.promoId, 80);
    saveDb((state) => {
      state.promoCodes = state.promoCodes.filter((p) => p.id !== promoId);
    });
    res.json({ ok: true });
  });

  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    const body = (req.body || {}) as {
      channelUsername?: unknown;
      channelUrl?: unknown;
      botUsername?: unknown;
      categories?: Partial<Record<CategoryKey, { title?: unknown; subtitle?: unknown }>>;
    };
    const channelUsername = sanitizeString(body.channelUsername, 80);
    const channelUrl = sanitizeString(body.channelUrl, 200);
    const botUsername = sanitizeString(body.botUsername, 80);

    if (channelUrl && !isSafeImageUrl(channelUrl)) {
      res.status(400).json({ error: 'Некорректная ссылка на канал' });
      return;
    }

    saveDb((state) => {
      if (channelUsername) state.settings.channelUsername = channelUsername;
      if (channelUrl) state.settings.channelUrl = channelUrl;
      if (botUsername) state.settings.botUsername = botUsername;
      if (body.categories && typeof body.categories === 'object') {
        const current = state.settings.categories || {
          ziphoodies: { title: 'Зип-худи', subtitle: 'Плотный футер 480–520 г/м² · Двойная молния' },
          tshirts: { title: 'Футболки', subtitle: 'Тяжелый хлопок · Boxy и Relaxed крой' },
          pants: { title: 'Брюки', subtitle: 'Технические карго и широкие модели со складками' },
        };
        for (const key of ['ziphoodies', 'tshirts', 'pants'] as const) {
          const patch = body.categories[key];
          if (patch && typeof patch === 'object') {
            const title = sanitizeString(patch.title, 60);
            const subtitle = sanitizeString(patch.subtitle, 120);
            current[key] = {
              title: title || current[key].title,
              subtitle: subtitle || current[key].subtitle,
            };
          }
        }
        state.settings.categories = current;
      }
    });

    res.json({ settings: getDb().settings });
  });

  // --- Vite Dev Middleware / Production Static Serving ---
  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Verlano server running on http://0.0.0.0:${PORT}`);

    const botToken = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
    const rawAppUrl = (process.env.APP_URL || '').trim().replace(/^["']|["']$/g, '');
    const isPreviewSandbox = /^https?:\/\/ais-(dev|pre)-[^/]+\.run\.app/i.test(rawAppUrl);

    if (!botToken) {
      console.log('TELEGRAM_BOT_TOKEN not set — Telegram bot polling skipped.');
    } else if (isPreviewSandbox) {
      console.log('AI Studio preview sandbox detected — Telegram bot polling disabled here.');
    } else {
      const webAppUrl =
        rawAppUrl && rawAppUrl !== 'MY_APP_URL' && /^https:\/\//i.test(rawAppUrl)
          ? rawAppUrl
          : 'https://verlano.online';
      startTelegramBotPolling(botToken, webAppUrl);
    }
  });
}

void startServer();
