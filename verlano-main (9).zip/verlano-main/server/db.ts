import fs from 'node:fs';
import path from 'node:path';
import type {
  CustomerProfile,
  NewsPost,
  Order,
  Product,
  PromoCode,
  StoreSettings,
} from '../src/types/store.ts';

export interface AdminAuthRecord {
  adminId: string;
  passwordSalt: string;
  passwordHash: string;
  claimedAt: string;
}

export interface DatabaseSchema {
  products: Product[];
  profiles: Record<string, CustomerProfile>;
  orders: Order[];
  promoCodes: PromoCode[];
  newsPosts: NewsPost[];
  settings: StoreSettings;
  adminAuth: AdminAuthRecord | null;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'verlano-db.json');

function createInitialData(): DatabaseSchema {
  const now = new Date().toISOString();
  return {
    products: [
      {
        id: 'verlano-tee-01',
        category: 'tshirts',
        name: 'Verlano Obsidian Boxy Tee',
        subtitle: 'Тяжелый хлопок · Архитектурный крой',
        description:
          'Укороченная и расширенная в плечах футболка из плотного вываренного хлопка с рельефными вертикальными швами и усиленной горловиной.',
        material: '100% органический хлопок · 320 г/м²',
        fit: 'Boxy Oversize',
        price: 4900,
        imageUrl: '/src/assets/images/verlano_tee_heavy_1795540088982.jpg',
        sizes: [
          { size: 'S', stock: 8 },
          { size: 'M', stock: 14 },
          { size: 'L', stock: 12 },
          { size: 'XL', stock: 6 },
        ],
        featured: true,
        createdAt: now,
      },
      {
        id: 'verlano-tee-02',
        category: 'tshirts',
        name: 'Verlano Mineral Ash Tee',
        subtitle: 'Минеральный меланж · Свободный силуэт',
        description:
          'Минималистичная базовая футболка оттенка холодного пепла с мягкой энзимной стиркой, спущенным плечом и незаметной внутренней планкой.',
        material: '100% гребенной хлопок · 290 г/м²',
        fit: 'Relaxed Fit',
        price: 4500,
        imageUrl: '/src/assets/images/verlano_tee_ash_1795540090249.jpg',
        sizes: [
          { size: 'S', stock: 10 },
          { size: 'M', stock: 15 },
          { size: 'L', stock: 9 },
          { size: 'XL', stock: 5 },
        ],
        featured: false,
        createdAt: now,
      },
      {
        id: 'verlano-pants-01',
        category: 'pants',
        name: 'Verlano Technical Cargo Trousers',
        subtitle: 'Скрытая фурнитура · Водоотталкивающая пропитка',
        description:
          'Широкие технологичные брюки-карго с матовыми скрытыми молниями, объемными накладными карманами и регулировкой по низу штанины.',
        material: 'Нейлон-рипстоп и хлопок · 260 г/м²',
        fit: 'Wide Utility',
        price: 9800,
        imageUrl: '/src/assets/images/verlano_pants_cargo_1795540090502.jpg',
        sizes: [
          { size: 'S', stock: 5 },
          { size: 'M', stock: 11 },
          { size: 'L', stock: 10 },
          { size: 'XL', stock: 4 },
        ],
        featured: true,
        createdAt: now,
      },
      {
        id: 'verlano-pants-02',
        category: 'pants',
        name: 'Verlano Architectural Pleated Pants',
        subtitle: 'Глубокие складки · Тяжелая костюмная ткань',
        description:
          'Широкие брюки со встречными складками у пояса и чистой вертикальной драпировкой. Идеально держат форму в движении.',
        material: 'Шерсть 45% / Вискоза 55% · 310 г/м²',
        fit: 'Wide Tailored',
        price: 10900,
        imageUrl: '/src/assets/images/verlano_pants_wide_1795540091056.jpg',
        sizes: [
          { size: 'S', stock: 4 },
          { size: 'M', stock: 8 },
          { size: 'L', stock: 7 },
          { size: 'XL', stock: 3 },
        ],
        featured: false,
        createdAt: now,
      },
      {
        id: 'verlano-zip-01',
        category: 'ziphoodies',
        name: 'Verlano Obsidian Double-Zip Hoodie',
        subtitle: 'Двусторонняя металлическая молния · Двойной капюшон',
        description:
          'Флагманское зип-худи из сверхплотного футера без начеса с матовой молнией цвета оружейной стали, широким кроем и структурным капюшоном.',
        material: '100% хлопок футер 3-нитка · 520 г/м²',
        fit: 'Boxy Heavyweight',
        price: 11400,
        imageUrl: '/src/assets/images/verlano_zip_obsidian_1795540091733.jpg',
        sizes: [
          { size: 'S', stock: 6 },
          { size: 'M', stock: 12 },
          { size: 'L', stock: 9 },
          { size: 'XL', stock: 5 },
        ],
        featured: true,
        createdAt: now,
      },
      {
        id: 'verlano-zip-02',
        category: 'ziphoodies',
        name: 'Verlano Slate Cropped Zip Hoodie',
        subtitle: 'Эффект вываренного графита · Реглан',
        description:
          'Укороченное зип-худи графитового оттенка с реглан-рукавом, обработанными необработанными швами и полированной серебристой молнией.',
        material: '100% вываренный хлопок · 480 г/м²',
        fit: 'Cropped Relaxed',
        price: 10200,
        imageUrl: '/src/assets/images/verlano_zip_slate_1795540091539.jpg',
        sizes: [
          { size: 'S', stock: 7 },
          { size: 'M', stock: 10 },
          { size: 'L', stock: 8 },
          { size: 'XL', stock: 4 },
        ],
        featured: false,
        createdAt: now,
      },
    ],
    profiles: {},
    orders: [],
    promoCodes: [
      {
        id: 'promo-verlano10',
        code: 'VERLANO10',
        discountPercent: 10,
        minOrderAmount: 4000,
        isPublic: true,
        active: true,
        description: 'Стартовая скидка 10% для всех подписчиков канала Verlano',
        createdAt: now,
      },
      {
        id: 'promo-drop20',
        code: 'FIRSTDROP',
        discountPercent: 15,
        minOrderAmount: 9000,
        isPublic: true,
        active: true,
        description: 'Скидка 15% на заказы от 9 000 ₽ на текущий монохромный дроп',
        createdAt: now,
      },
    ],
    newsPosts: [
      {
        id: 'news-1',
        title: 'Monochrome Drop 01 уже доступен в Mini App',
        summary:
          'Шесть базовых силуэтов в оттенках обсидиана, пепла и графита. Плотность тканей от 290 до 520 г/м².',
        date: '24 ноября 2026',
        tag: 'Релиз',
      },
      {
        id: 'news-2',
        title: 'Скоро в ассортименте: лонгсливы, верхняя одежда и аксессуары',
        summary:
          'Следующая волна коллекции Verlano выйдет в декабре. Подписчики канала получат ранний доступ и закрытый промокод.',
        date: '20 ноября 2026',
        tag: 'Анонс',
      },
    ],
    settings: {
      brandName: 'Verlano',
      channelUsername: process.env.TELEGRAM_CHANNEL_ID || '@verlano_news',
      channelUrl: process.env.TELEGRAM_CHANNEL_URL || 'https://t.me/verlano_news',
      botUsername: '@verlano_shop_bot',
      categories: {
        ziphoodies: {
          title: 'Зип-худи',
          subtitle: 'Плотный футер 480–520 г/м² · Двойная молния',
        },
        tshirts: {
          title: 'Футболки',
          subtitle: 'Тяжелый хлопок · Boxy и Relaxed крой',
        },
        pants: {
          title: 'Брюки',
          subtitle: 'Технические карго и широкие модели со складками',
        },
      },
    },
    adminAuth: null,
  };
}

let cachedDb: DatabaseSchema | null = null;

function ensureDbFile(): DatabaseSchema {
  if (cachedDb) {
    return cachedDb;
  }
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    const initial = createInitialData();
    writeDbAtomically(initial);
    cachedDb = initial;
    return cachedDb;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<DatabaseSchema>;
    const defaults = createInitialData();
    cachedDb = {
      products: Array.isArray(parsed.products) && parsed.products.length > 0 ? parsed.products : defaults.products,
      profiles: parsed.profiles && typeof parsed.profiles === 'object' ? parsed.profiles : {},
      orders: Array.isArray(parsed.orders) ? parsed.orders : [],
      promoCodes: Array.isArray(parsed.promoCodes) ? parsed.promoCodes : defaults.promoCodes,
      newsPosts: Array.isArray(parsed.newsPosts) && parsed.newsPosts.length > 0 ? parsed.newsPosts : defaults.newsPosts,
      settings: parsed.settings
        ? {
            brandName: parsed.settings.brandName || defaults.settings.brandName,
            channelUsername: process.env.TELEGRAM_CHANNEL_ID || parsed.settings.channelUsername || defaults.settings.channelUsername,
            channelUrl: process.env.TELEGRAM_CHANNEL_URL || parsed.settings.channelUrl || defaults.settings.channelUrl,
            botUsername: parsed.settings.botUsername || defaults.settings.botUsername,
            categories: {
              ziphoodies: parsed.settings.categories?.ziphoodies || defaults.settings.categories!.ziphoodies,
              tshirts: parsed.settings.categories?.tshirts || defaults.settings.categories!.tshirts,
              pants: parsed.settings.categories?.pants || defaults.settings.categories!.pants,
            },
          }
        : defaults.settings,
      adminAuth: parsed.adminAuth ?? null,
    };
    return cachedDb;
  } catch {
    const initial = createInitialData();
    writeDbAtomically(initial);
    cachedDb = initial;
    return cachedDb;
  }
}

function writeDbAtomically(data: DatabaseSchema): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpFile = `${DB_FILE}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

export function getDb(): DatabaseSchema {
  return ensureDbFile();
}

export function saveDb(mutator: (db: DatabaseSchema) => void): DatabaseSchema {
  const db = ensureDbFile();
  mutator(db);
  writeDbAtomically(db);
  return db;
}

export function getOrCreateProfile(userId: string, defaults?: Partial<CustomerProfile>): CustomerProfile {
  const db = ensureDbFile();
  const existing = db.profiles[userId];
  if (existing) {
    return existing;
  }
  const created: CustomerProfile = {
    userId,
    nickname: defaults?.nickname || `guest_${userId.slice(-4)}`,
    firstName: defaults?.firstName || '',
    lastName: defaults?.lastName || '',
    phone: '',
    address: '',
    deliveryNote: '',
    avatarUrl: defaults?.avatarUrl || '',
    demoSubscribed: false,
    updatedAt: new Date().toISOString(),
  };
  saveDb((state) => {
    state.profiles[userId] = created;
  });
  return created;
}
