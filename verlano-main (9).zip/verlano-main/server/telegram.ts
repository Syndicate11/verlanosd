import crypto from 'node:crypto';
import type { Order } from '../src/types/store.ts';

export interface VerifiedTelegramUser {
  id: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  photoUrl?: string;
  verified: boolean;
}

export function verifyTelegramInitData(initData: string, botToken: string): VerifiedTelegramUser | null {
  if (!initData || !botToken) {
    return null;
  }
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');
    if (!hash) {
      return null;
    }

    const entries: string[] = [];
    params.forEach((value, key) => {
      if (key !== 'hash') {
        entries.push(`${key}=${value}`);
      }
    });
    entries.sort();
    const dataCheckString = entries.join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const expectedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    const hashBuf = Buffer.from(hash, 'hex');
    const expectedBuf = Buffer.from(expectedHash, 'hex');
    if (hashBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(hashBuf, expectedBuf)) {
      return null;
    }

    const userRaw = params.get('user');
    if (!userRaw) {
      return null;
    }
    const user = JSON.parse(userRaw) as {
      id?: number | string;
      username?: string;
      first_name?: string;
      last_name?: string;
      photo_url?: string;
    };
    if (!user.id) {
      return null;
    }

    return {
      id: String(user.id),
      username: user.username,
      firstName: user.first_name,
      lastName: user.last_name,
      photoUrl: user.photo_url,
      verified: true,
    };
  } catch {
    return null;
  }
}

export async function checkTelegramChannelMembership(
  botToken: string,
  channelId: string,
  userId: string
): Promise<{ ok: boolean; subscribed: boolean; error?: string }> {
  let normalizedChannelId = (channelId || '').trim().replace(/^["']|["']$/g, '');
  const tmeMatch = normalizedChannelId.match(/^(?:https?:\/\/)?t\.me\/([A-Za-z0-9_]{4,})$/i);
  if (tmeMatch) {
    normalizedChannelId = `@${tmeMatch[1]}`;
  }

  if (!botToken || !normalizedChannelId || !userId) {
    return { ok: false, subscribed: false, error: 'Missing Telegram configuration' };
  }
  try {
    const url = new URL(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/getChatMember`);
    url.searchParams.set('chat_id', normalizedChannelId);
    url.searchParams.set('user_id', userId);

    const response = await fetch(url.toString(), {
      method: 'GET',
      signal: AbortSignal.timeout(5000),
    });

    const data = (await response.json()) as {
      ok: boolean;
      result?: { status?: string };
      description?: string;
    };

    if (!data.ok || !data.result) {
      const rawError = data.description || 'Telegram API error';
      console.warn(`getChatMember failed for chat_id="${normalizedChannelId}": ${rawError}`);
      if (/chat not found|member list is inaccessible|bot is not a member/i.test(rawError)) {
        return {
          ok: false,
          subscribed: false,
          error:
            'Не удалось проверить подписку. Убедитесь, что бот добавлен в администраторы канала и указан верный канал.',
        };
      }
      return { ok: false, subscribed: false, error: rawError };
    }

    const activeStatuses = new Set(['creator', 'administrator', 'member', 'restricted']);
    return {
      ok: true,
      subscribed: Boolean(data.result.status && activeStatuses.has(data.result.status)),
    };
  } catch (err) {
    return {
      ok: false,
      subscribed: false,
      error: err instanceof Error ? err.message : 'Network error',
    };
  }
}

export async function notifyAdminsOfOrder(
  botToken: string,
  adminIds: string[],
  order: Order
): Promise<void> {
  if (!botToken || adminIds.length === 0) {
    return;
  }

  const lines = [
    `Новый заказ Verlano ${order.orderNumber}`,
    `Покупатель: ${order.customerSnapshot.firstName} ${order.customerSnapshot.lastName} (@${order.customerSnapshot.nickname})`,
    `Телефон: ${order.customerSnapshot.phone}`,
    `Адрес: ${order.customerSnapshot.address}`,
    order.customerSnapshot.deliveryNote ? `Комментарий: ${order.customerSnapshot.deliveryNote}` : '',
    '',
    'Позиции:',
    ...order.items.map((item) => `• ${item.name} [${item.size}] × ${item.quantity} — ${item.unitPrice * item.quantity} ₽`),
    '',
    order.promoCode ? `Промокод: ${order.promoCode} (-${order.discountAmount} ₽)` : '',
    `Итого к оплате: ${order.totalAmount} ₽`,
  ].filter(Boolean);

  const text = lines.join('\n');

  await Promise.allSettled(
    adminIds.map((chatId) =>
      fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
        }),
        signal: AbortSignal.timeout(5000),
      })
    )
  );
}

export async function notifyCustomerOrderStatus(
  botToken: string,
  userId: string,
  orderNumber: string,
  statusLabel: string
): Promise<void> {
  if (!botToken || !userId || userId.startsWith('demo_')) {
    return;
  }
  try {
    await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: userId,
        text: `Verlano · Статус вашего заказа ${orderNumber} обновлен: ${statusLabel}`,
      }),
      signal: AbortSignal.timeout(5000),
    });
  } catch {
    // Non-blocking notification
  }
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    chat?: {
      id: number;
      type?: string;
    };
    from?: {
      id: number;
      first_name?: string;
      username?: string;
    };
    text?: string;
  };
}

function isHttpsUrl(value: string): boolean {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

async function callTelegramApi<T = unknown>(
  botToken: string,
  method: string,
  payload?: Record<string, unknown>,
  timeoutMs = 10_000
): Promise<{ ok: boolean; result?: T; error_code?: number; description?: string }> {
  const response = await fetch(
    `https://api.telegram.org/bot${encodeURIComponent(botToken)}/${method}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload ?? {}),
      signal: AbortSignal.timeout(timeoutMs),
    }
  );
  return (await response.json()) as {
    ok: boolean;
    result?: T;
    error_code?: number;
    description?: string;
  };
}

export function startTelegramBotPolling(botToken: string, webAppUrl: string): () => void {
  let stopped = false;
  let offset = 0;
  let retryDelayMs = 2000;
  const hasHttpsWebApp = isHttpsUrl(webAppUrl);

  async function sendWelcome(chatId: number, firstName?: string): Promise<void> {
    const greetingName = firstName ? `, ${firstName}` : '';
    const text = [
      `Привет${greetingName}! Вас приветствует магазин одежды Verlano.`,
      '',
      'Актуальная коллекция, размеры в наличии, промокоды и оформление заказа — всё внутри нашего Mini App.',
      '',
      'Нажмите на кнопку ниже, чтобы открыть магазин:',
    ].join('\n');

    const payload: Record<string, unknown> = {
      chat_id: chatId,
      text,
    };

    if (hasHttpsWebApp) {
      payload.reply_markup = {
        inline_keyboard: [
          [
            {
              text: 'Открыть магазин Verlano',
              web_app: { url: webAppUrl },
            },
          ],
        ],
      };
    }

    await callTelegramApi(botToken, 'sendMessage', payload, 10_000);
  }

  async function bootstrapBot(): Promise<void> {
    try {
      await callTelegramApi(botToken, 'deleteWebhook', { drop_pending_updates: false });
      await callTelegramApi(botToken, 'setMyCommands', {
        commands: [{ command: 'start', description: 'Открыть магазин Verlano' }],
      });
      if (hasHttpsWebApp) {
        await callTelegramApi(botToken, 'setChatMenuButton', {
          menu_button: {
            type: 'web_app',
            text: 'Магазин',
            web_app: { url: webAppUrl },
          },
        });
      }
      console.log(
        `Verlano Telegram bot polling started${hasHttpsWebApp ? ` (Mini App: ${webAppUrl})` : ' (APP_URL is not HTTPS — web_app button disabled)'}`
      );
    } catch (err) {
      console.error('Telegram bot bootstrap error:', err instanceof Error ? err.message : err);
    }
  }

  async function pollLoop(): Promise<void> {
    await bootstrapBot();

    while (!stopped) {
      try {
        const res = await callTelegramApi<TelegramUpdate[]>(
          botToken,
          'getUpdates',
          {
            offset,
            timeout: 25,
            allowed_updates: ['message'],
          },
          35_000
        );

        if (!res.ok) {
          if (res.error_code === 409) {
            console.warn('Telegram bot conflict (409): another bot instance may be running. Retrying...');
            retryDelayMs = 10_000;
          } else {
            console.warn('Telegram getUpdates error:', res.description || res.error_code);
            retryDelayMs = Math.min(retryDelayMs * 2, 15_000);
          }
          await new Promise((r) => setTimeout(r, retryDelayMs));
          continue;
        }

        retryDelayMs = 2000;
        const updates = res.result || [];
        for (const update of updates) {
          offset = Math.max(offset, update.update_id + 1);
          const msg = update.message;
          const text = msg?.text?.trim();
          const chatId = msg?.chat?.id;
          if (!msg || !chatId || !text) {
            continue;
          }

          if (text === '/start' || text.startsWith('/start ') || text === '/menu') {
            await sendWelcome(chatId, msg.from?.first_name).catch((err) => {
              console.error('Failed to send /start welcome:', err instanceof Error ? err.message : err);
            });
          }
        }
      } catch (err) {
        if (stopped) {
          break;
        }
        const msg = err instanceof Error ? err.message : String(err);
        if (!msg.includes('aborted')) {
          console.warn('Telegram polling network retry:', msg);
        }
        await new Promise((r) => setTimeout(r, retryDelayMs));
        retryDelayMs = Math.min(retryDelayMs * 2, 15_000);
      }
    }
  }

  void pollLoop();

  return () => {
    stopped = true;
  };
}

