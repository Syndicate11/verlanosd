import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, CheckCircle2, Newspaper, RefreshCw } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import { getTelegramWebApp } from '../lib/api';
import type { NewsPost, StoreSettings, SubscriptionCheckResult } from '../types/store';

interface NewsSectionProps {
  settings: StoreSettings;
  newsPosts: NewsPost[];
  subscription: SubscriptionCheckResult;
  onRecheckSubscription: () => Promise<void>;
}

export function NewsSection({
  settings,
  newsPosts,
  subscription,
  onRecheckSubscription,
}: NewsSectionProps) {
  const [checking, setChecking] = useState(false);

  const openChannel = () => {
    const tg = getTelegramWebApp();
    if (tg?.openTelegramLink && settings.channelUrl.startsWith('https://t.me/')) {
      tg.openTelegramLink(settings.channelUrl);
    } else {
      window.open(settings.channelUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleRecheck = async () => {
    setChecking(true);
    try {
      await onRecheckSubscription();
    } finally {
      setChecking(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="border-b border-white/10 pb-4">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#8A8A8E]">
          Лента релизов
        </p>
        <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-[#F5F5F5] sm:text-4xl">
          Новости Verlano
        </h2>
      </div>

      <SpotlightCard className="p-6">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center border border-white/15 bg-[#141417]">
              <Newspaper className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2.5">
                <h3 className="font-display text-2xl font-medium text-[#F5F5F5]">
                  {settings.channelUsername.startsWith('@')
                    ? settings.channelUsername
                    : 'Канал Verlano'}
                </h3>
                <span className="inline-flex items-center gap-1.5 font-mono text-xs text-white">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>
                    {subscription.subscribed ? 'Подписка активна' : 'Требуется подписка'}
                  </span>
                </span>
              </div>
              <p className="mt-1 text-sm text-[#8A8A8E]">
                Официальный Telegram-канал бренда: анонсы новых дропов, пополнение размеров и
                закрытые промокоды.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleRecheck}
              disabled={checking}
              className="flex min-h-[42px] items-center gap-2 border border-white/15 bg-[#141417] px-4 py-2 text-xs font-medium text-[#F5F5F5] transition-colors hover:border-white/40"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${checking ? 'animate-spin' : ''}`} />
              <span>Обновить статус</span>
            </button>
            <button
              type="button"
              onClick={openChannel}
              className="flex min-h-[42px] items-center gap-2 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90"
            >
              <span>Открыть канал</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </SpotlightCard>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {newsPosts.map((post) => (
          <SpotlightCard key={post.id} className="p-6">
            <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
              <span className="text-white">{post.tag}</span>
              <span aria-hidden="true">·</span>
              <span>{post.date}</span>
            </div>
            <h3 className="font-display mt-2.5 text-2xl font-medium text-[#F5F5F5]">
              {post.title}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[#8A8A8E]">{post.summary}</p>
          </SpotlightCard>
        ))}
      </div>
    </motion.div>
  );
}
