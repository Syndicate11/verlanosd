import { motion } from 'motion/react';

export function SplashScreen() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#080809] px-6"
    >
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center"
      >
        <h1 className="font-display text-5xl font-medium tracking-[0.26em] text-white sm:text-6xl">
          VERLANO
        </h1>
        <p className="mt-2.5 text-xs tracking-[0.18em] text-[#8A8A8E]">
          Магазин одежды
        </p>
        <div className="mt-7 h-px w-40 overflow-hidden bg-white/[0.1]">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 1.05, ease: [0.16, 1, 0.3, 1] }}
            className="h-full w-full bg-gradient-to-r from-transparent via-white to-transparent"
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
