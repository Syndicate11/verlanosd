import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Minus, Plus, ShoppingBag, Tag, Trash2 } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import { formatPrice, ORDER_STATUS_TEXT, validatePromoCode } from '../lib/api';
import type { CartEntry, CustomerProfile, Order, Product, PromoCode } from '../types/store';

interface CartSectionProps {
  cart: CartEntry[];
  products: Product[];
  profile: CustomerProfile;
  appliedPromo: PromoCode | null;
  onApplyPromo: (promo: PromoCode | null) => void;
  onUpdateQuantity: (productId: string, size: 'S' | 'M' | 'L' | 'XL', delta: number) => void;
  onRemoveItem: (productId: string, size: 'S' | 'M' | 'L' | 'XL') => void;
  onSubmitOrder: (customer: {
    nickname: string;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    deliveryNote: string;
  }) => Promise<Order>;
  onGoToCatalog: () => void;
}

export function CartSection({
  cart,
  products,
  profile,
  appliedPromo,
  onApplyPromo,
  onUpdateQuantity,
  onRemoveItem,
  onSubmitOrder,
  onGoToCatalog,
}: CartSectionProps) {
  const [promoInput, setPromoInput] = useState(appliedPromo?.code || '');
  const [promoError, setPromoError] = useState('');
  const [promoLoading, setPromoLoading] = useState(false);

  const [delivery, setDelivery] = useState({
    nickname: profile.nickname || '',
    firstName: profile.firstName || '',
    lastName: profile.lastName || '',
    phone: profile.phone || '',
    address: profile.address || '',
    deliveryNote: profile.deliveryNote || '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  useEffect(() => {
    setDelivery({
      nickname: profile.nickname || '',
      firstName: profile.firstName || '',
      lastName: profile.lastName || '',
      phone: profile.phone || '',
      address: profile.address || '',
      deliveryNote: profile.deliveryNote || '',
    });
  }, [profile]);

  const enrichedItems = cart
    .map((entry) => {
      const product = products.find((p) => p.id === entry.productId);
      if (!product) return null;
      return { entry, product };
    })
    .filter((v): v is { entry: CartEntry; product: Product } => v !== null);

  const subtotal = enrichedItems.reduce(
    (sum, { entry, product }) => sum + product.price * entry.quantity,
    0
  );

  const promoEligible =
    appliedPromo && subtotal >= appliedPromo.minOrderAmount ? appliedPromo : null;
  const discountAmount = promoEligible
    ? Math.round((subtotal * promoEligible.discountPercent) / 100)
    : 0;
  const totalAmount = Math.max(0, subtotal - discountAmount);

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    setPromoLoading(true);
    try {
      const { promo } = await validatePromoCode(promoInput, subtotal);
      onApplyPromo(promo);
    } catch (err) {
      setPromoError(err instanceof Error ? err.message : 'Не удалось применить промокод');
    } finally {
      setPromoLoading(false);
    }
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!delivery.firstName.trim() || !delivery.phone.trim() || !delivery.address.trim()) {
      setSubmitError('Заполните имя, телефон и адрес доставки для оформления');
      return;
    }
    setSubmitting(true);
    try {
      const order = await onSubmitOrder(delivery);
      setCompletedOrder(order);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Ошибка оформления заказа');
    } finally {
      setSubmitting(false);
    }
  };

  if (completedOrder) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="mx-auto max-w-2xl"
      >
        <SpotlightCard className="p-6 sm:p-8">
          <div className="flex items-center gap-3.5 border-b border-white/10 pb-5">
            <div className="flex h-11 w-11 items-center justify-center border border-white/30 bg-white/[0.06] text-white">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-[#8A8A8E]">
                Заказ передан в обработку
              </p>
              <h2 className="font-display mt-0.5 text-2xl font-medium text-[#F5F5F5]">
                {completedOrder.orderNumber} · {ORDER_STATUS_TEXT[completedOrder.status]}
              </h2>
            </div>
          </div>

          <div className="mt-5 space-y-3 text-sm">
            {completedOrder.items.map((item, i) => (
              <div key={i} className="flex items-center justify-between text-[#F5F5F5]">
                <span>
                  {item.name} · <span className="font-mono text-xs text-[#8A8A8E]">{item.size}</span> ×{' '}
                  {item.quantity}
                </span>
                <span className="font-mono tabular-nums">
                  {formatPrice(item.unitPrice * item.quantity)}
                </span>
              </div>
            ))}

            {completedOrder.promoCode && (
              <div className="flex items-center justify-between text-xs text-white/80">
                <span>Промокод {completedOrder.promoCode}</span>
                <span className="font-mono tabular-nums">
                  -{formatPrice(completedOrder.discountAmount)}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between border-t border-white/10 pt-3 text-base font-semibold text-[#F5F5F5]">
              <span>Итого</span>
              <span className="font-mono tabular-nums">
                {formatPrice(completedOrder.totalAmount)}
              </span>
            </div>
          </div>

          <div className="mt-6 border border-white/10 bg-[#080809] p-4 text-xs leading-relaxed text-[#8A8A8E]">
            <p className="font-medium text-[#F5F5F5]">
              Получатель: {completedOrder.customerSnapshot.firstName}{' '}
              {completedOrder.customerSnapshot.lastName}
            </p>
            <p className="mt-1">Телефон: {completedOrder.customerSnapshot.phone}</p>
            <p className="mt-1">Адрес: {completedOrder.customerSnapshot.address}</p>
          </div>

          <button
            type="button"
            onClick={() => {
              setCompletedOrder(null);
              onGoToCatalog();
            }}
            className="mt-6 flex min-h-[48px] w-full items-center justify-center gap-2 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#080809] transition-colors hover:bg-white/90"
          >
            <span>Вернуться в каталог</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </SpotlightCard>
      </motion.div>
    );
  }

  if (enrichedItems.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      >
        <SpotlightCard className="flex flex-col items-center justify-center px-6 py-16 text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center border border-white/15 bg-[#141417]">
            <ShoppingBag className="h-6 w-6 text-[#8A8A8E]" />
          </div>
          <h2 className="font-display text-3xl font-medium text-[#F5F5F5]">Корзина пуста</h2>
          <p className="mt-2 max-w-sm text-sm text-[#8A8A8E]">
            Перейдите в каталог Verlano, чтобы выбрать модель и нужный размер.
          </p>
          <button
            type="button"
            onClick={onGoToCatalog}
            className="mt-6 flex min-h-[46px] items-center gap-2 bg-white px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#080809] transition-colors hover:bg-white/90"
          >
            <span>Открыть каталог</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </SpotlightCard>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="border-b border-white/10 pb-4">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#8A8A8E]">
          Оформление заказа
        </p>
        <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-[#F5F5F5] sm:text-4xl">
          Корзина
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
        <div className="space-y-4 lg:col-span-7">
          {enrichedItems.map(({ entry, product }) => {
            const stock = product.sizes.find((s) => s.size === entry.size)?.stock ?? 10;
            return (
              <SpotlightCard key={`${entry.productId}-${entry.size}`} className="p-4 sm:p-5">
                <div className="flex items-center gap-4">
                  <div className="h-20 w-24 shrink-0 overflow-hidden border border-white/10 bg-[#080809]">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-display truncate text-xl font-medium text-[#F5F5F5]">
                      {product.name}
                    </p>
                    <p className="mt-0.5 font-mono text-xs text-[#8A8A8E]">
                      Размер {entry.size} · {formatPrice(product.price)} / шт.
                    </p>

                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-1.5 border border-white/15 bg-[#080809] p-1">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(entry.productId, entry.size, -1)}
                          aria-label="Уменьшить количество"
                          className="flex h-8 w-8 items-center justify-center text-[#F5F5F5] transition-colors hover:bg-white/10"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="min-w-[28px] text-center font-mono text-xs font-medium text-[#F5F5F5] tabular-nums">
                          {entry.quantity}
                        </span>
                        <button
                          type="button"
                          disabled={entry.quantity >= stock}
                          onClick={() => onUpdateQuantity(entry.productId, entry.size, 1)}
                          aria-label="Увеличить количество"
                          className="flex h-8 w-8 items-center justify-center text-[#F5F5F5] transition-colors hover:bg-white/10 disabled:opacity-40"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="font-mono text-sm font-medium text-[#F5F5F5] tabular-nums">
                          {formatPrice(product.price * entry.quantity)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(entry.productId, entry.size)}
                          aria-label="Удалить товар"
                          className="flex h-9 w-9 items-center justify-center border border-white/10 text-[#A1A1AA] transition-colors hover:border-white/30 hover:bg-white/10 hover:text-white"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </SpotlightCard>
            );
          })}
        </div>

        <SpotlightCard className="p-6 lg:col-span-5">
          <form onSubmit={handleApplyPromo} className="border-b border-white/10 pb-5">
            <label className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
              Промокод
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={promoInput}
                onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                placeholder="VERLANO10"
                className="flex-1 border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm uppercase text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />
              <button
                type="submit"
                disabled={promoLoading || !promoInput.trim()}
                className="flex min-h-[42px] items-center gap-1.5 border border-white/15 bg-[#141417] px-4 text-xs font-medium text-[#F5F5F5] transition-colors hover:border-white/40 disabled:opacity-40"
              >
                <Tag className="h-3.5 w-3.5 text-white" />
                <span>Применить</span>
              </button>
            </div>
            {promoError && <p className="mt-2 text-xs text-white/80">{promoError}</p>}
            {appliedPromo && (
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-white">
                  {promoEligible
                    ? `Активен ${appliedPromo.code} (-${appliedPromo.discountPercent}%)`
                    : `Для ${appliedPromo.code} нужна сумма от ${formatPrice(appliedPromo.minOrderAmount)}`}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onApplyPromo(null);
                    setPromoInput('');
                  }}
                  className="text-[#8A8A8E] hover:text-white"
                >
                  Убрать
                </button>
              </div>
            )}
          </form>

          <form onSubmit={handleCheckout} className="mt-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-[#F5F5F5]">Данные получателя</h3>
              <span className="text-xs text-[#8A8A8E]">На этот заказ</span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <input
                type="text"
                value={delivery.firstName}
                onChange={(e) => setDelivery((p) => ({ ...p, firstName: e.target.value }))}
                placeholder="Имя *"
                className="border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />
              <input
                type="text"
                value={delivery.lastName}
                onChange={(e) => setDelivery((p) => ({ ...p, lastName: e.target.value }))}
                placeholder="Фамилия"
                className="border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />
            </div>

            <input
              type="tel"
              value={delivery.phone}
              onChange={(e) => setDelivery((p) => ({ ...p, phone: e.target.value }))}
              placeholder="Телефон *"
              className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
            />

            <input
              type="text"
              value={delivery.address}
              onChange={(e) => setDelivery((p) => ({ ...p, address: e.target.value }))}
              placeholder="Адрес доставки или пункт выдачи *"
              className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
            />

            <input
              type="text"
              value={delivery.deliveryNote}
              onChange={(e) => setDelivery((p) => ({ ...p, deliveryNote: e.target.value }))}
              placeholder="Комментарий курьеру"
              className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
            />

            <div className="space-y-2 border-t border-white/10 pt-4 text-sm">
              <div className="flex justify-between text-[#8A8A8E]">
                <span>Товары</span>
                <span className="font-mono tabular-nums">{formatPrice(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-white">
                  <span>Скидка по промокоду</span>
                  <span className="font-mono tabular-nums">-{formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-semibold text-[#F5F5F5]">
                <span>Итого</span>
                <span className="font-mono tabular-nums">{formatPrice(totalAmount)}</span>
              </div>
            </div>

            {submitError && (
              <p className="border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
                {submitError}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#080809] transition-colors hover:bg-white/90 active:scale-[0.99] disabled:opacity-60"
            >
              <span>{submitting ? 'Отправка заявки...' : 'Оформить заказ'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        </SpotlightCard>
      </div>
    </motion.div>
  );
}
