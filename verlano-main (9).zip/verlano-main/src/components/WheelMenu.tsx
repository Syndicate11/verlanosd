import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { formatPrice } from '../lib/api';
import type { AppSection, CustomerProfile, NewsPost } from '../types/store';

interface WheelMenuProps {
  onSelectSection: (section: Exclude<AppSection, 'wheel'>) => void;
  cartCount: number;
  cartSubtotal: number;
  profile: CustomerProfile;
  newsPosts: NewsPost[];
  publicPromosCount: number;
  activeIndex: number;
  onChangeIndex: (index: number) => void;
}

interface CarouselSlide {
  id: Exclude<AppSection, 'wheel'>;
  indexLabel: string;
  title: string;
  description: string;
  ctaLabel: string;
  imageUrl: string;
}

const SLIDES: CarouselSlide[] = [
  {
    id: 'order',
    indexLabel: '01',
    title: 'Заказать',
    description: 'Каталог моделей, выбор размера и оформление.',
    ctaLabel: 'Открыть каталог',
    imageUrl: '/src/assets/images/icon_menu_order_1795557451035.jpg',
  },
  {
    id: 'cart',
    indexLabel: '02',
    title: 'Корзина',
    description: 'Выбранные позиции, промокод и доставка.',
    ctaLabel: 'Перейти в корзину',
    imageUrl: '/src/assets/images/icon_menu_cart_1795557451242.jpg',
  },
  {
    id: 'profile',
    indexLabel: '03',
    title: 'Профиль',
    description: 'Данные получателя и история ваших заказов.',
    ctaLabel: 'Открыть профиль',
    imageUrl: '/src/assets/images/icon_menu_profile_1795557452003.jpg',
  },
  {
    id: 'promocodes',
    indexLabel: '04',
    title: 'Промокоды',
    description: 'Персональные скидки и доступные акции.',
    ctaLabel: 'Открыть коды',
    imageUrl: '/src/assets/images/icon_menu_promo_1795557452391.jpg',
  },
  {
    id: 'news',
    indexLabel: '05',
    title: 'Новости',
    description: 'Анонсы релизов и переход в Telegram-канал.',
    ctaLabel: 'Читать новости',
    imageUrl: '/src/assets/images/icon_menu_news_1795557452647.jpg',
  },
  {
    id: 'admin',
    indexLabel: '06',
    title: 'Админ-панель',
    description: 'Товары, категории, заказы и настройки.',
    ctaLabel: 'Войти',
    imageUrl: '/src/assets/images/icon_menu_admin_1795557453873.jpg',
  },
];

export function WheelMenu({
  onSelectSection,
  cartCount,
  cartSubtotal,
  profile,
  newsPosts,
  publicPromosCount,
  activeIndex,
  onChangeIndex,
}: WheelMenuProps) {
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const pointerDragStartXRef = useRef<number | null>(null);
  const wheelLockRef = useRef(0);
  const [dragOffsetPx, setDragOffsetPx] = useState(0);

  const clampedIndex = Math.max(0, Math.min(SLIDES.length - 1, activeIndex));

  const goTo = (nextIndex: number) => {
    const target = Math.max(0, Math.min(SLIDES.length - 1, nextIndex));
    onChangeIndex(target);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const t = e.touches[0];
    if (!t) return;
    touchStartRef.current = { x: t.clientX, y: t.clientY };
    setDragOffsetPx(0);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current) return;
    const t = e.touches[0];
    if (!t) return;
    const dx = t.clientX - touchStartRef.current.x;
    const dy = t.clientY - touchStartRef.current.y;
    if (Math.abs(dx) > Math.abs(dy)) {
      setDragOffsetPx(Math.max(-140, Math.min(140, dx * 0.65)));
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current) {
      setDragOffsetPx(0);
      return;
    }
    const t = e.changedTouches[0];
    if (t) {
      const dx = t.clientX - touchStartRef.current.x;
      if (dx <= -42) {
        goTo(clampedIndex + 1);
      } else if (dx >= 42) {
        goTo(clampedIndex - 1);
      }
    }
    touchStartRef.current = null;
    setDragOffsetPx(0);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    pointerDragStartXRef.current = e.clientX;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch' || pointerDragStartXRef.current === null) return;
    const dx = e.clientX - pointerDragStartXRef.current;
    pointerDragStartXRef.current = null;
    if (dx <= -48) {
      goTo(clampedIndex + 1);
    } else if (dx >= 48) {
      goTo(clampedIndex - 1);
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    const dominant = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    const now = Date.now();
    if (Math.abs(dominant) < 16 || now - wheelLockRef.current < 240) return;
    wheelLockRef.current = now;
    goTo(clampedIndex + (dominant > 0 ? 1 : -1));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      goTo(clampedIndex + 1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      goTo(clampedIndex - 1);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onSelectSection(SLIDES[clampedIndex].id);
    }
  };

  const getSlideLiveStat = (slideId: CarouselSlide['id']): string => {
    switch (slideId) {
      case 'order':
        return 'В наличии';
      case 'cart':
        return cartCount > 0
          ? `${cartCount} поз. · ${formatPrice(cartSubtotal)}`
          : 'Пусто';
      case 'profile': {
        const fullName = [profile.firstName, profile.lastName].filter(Boolean).join(' ');
        return fullName || `@${profile.nickname || 'verlano'}`;
      }
      case 'promocodes':
        return publicPromosCount > 0
          ? `Открытых: ${publicPromosCount}`
          : 'Скидки';
      case 'news':
        return newsPosts[0]?.date || 'Канал';
      case 'admin':
        return 'Управление';
    }
  };

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onWheel={handleWheel}
      className="flex h-[calc(100dvh-56px)] flex-col justify-between overflow-hidden bg-[#080809] pb-8 pt-4 outline-none select-none"
    >
      {/* Horizontal Carousel Stage */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        className="relative flex flex-1 items-center justify-center overflow-hidden touch-pan-x"
      >
        <div className="relative h-[440px] w-full max-w-[325px] sm:h-[470px] sm:max-w-[380px]">
          {SLIDES.map((slide, idx) => {
            const offset = idx - clampedIndex;
            const absOffset = Math.abs(offset);
            const isActive = offset === 0;
            const xPercent = offset * 92;
            const scale = isActive ? 1 : Math.max(0.84, 1 - absOffset * 0.11);
            const opacity = isActive ? 1 : absOffset === 1 ? 0.34 : 0;

            return (
              <motion.div
                key={slide.id}
                animate={{
                  x: `calc(${xPercent}% + ${dragOffsetPx}px)`,
                  scale,
                  opacity,
                }}
                transition={{
                  type: 'spring',
                  stiffness: 230,
                  damping: 28,
                }}
                style={{
                  zIndex: isActive ? 30 : 20 - absOffset,
                  pointerEvents: absOffset <= 1 ? 'auto' : 'none',
                }}
                onClick={() => {
                  if (isActive) {
                    onSelectSection(slide.id);
                  } else {
                    goTo(idx);
                  }
                }}
                className={`absolute inset-0 flex cursor-pointer flex-col justify-between overflow-hidden rounded-[2px] border bg-[#0A0A0C] transition-colors ${
                  isActive
                    ? 'border-white/30 shadow-[0_24px_60px_rgba(0,0,0,0.8)]'
                    : 'border-white/[0.08]'
                }`}
              >
                {/* Top Minimal Metadata */}
                <div className="flex items-center justify-between border-b border-white/[0.08] px-6 py-4">
                  <span className="font-mono text-xs text-[#8A8A8E] tabular-nums">
                    {slide.indexLabel}
                  </span>
                  <span className="font-mono text-xs text-white/80 tabular-nums">
                    {getSlideLiveStat(slide.id)}
                  </span>
                </div>

                {/* Centered Minimalist Monochrome 3D Icon Model */}
                <div className="relative flex flex-1 items-center justify-center overflow-hidden bg-[#080809] px-6 py-4">
                  <img
                    src={slide.imageUrl}
                    alt={slide.title}
                    referrerPolicy="no-referrer"
                    draggable={false}
                    className={`h-44 w-44 object-contain transition-transform duration-500 sm:h-52 sm:w-52 ${
                      isActive ? 'scale-100 opacity-100' : 'scale-95 opacity-60'
                    }`}
                  />
                </div>

                {/* Bottom Title & Action */}
                <div className="border-t border-white/[0.08] bg-[#0D0D0F] p-6">
                  <h2 className="font-display text-3xl font-medium tracking-tight text-white sm:text-4xl">
                    {slide.title}
                  </h2>
                  <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-[#8A8A8E]">
                    {slide.description}
                  </p>

                  <div className="mt-4 flex items-center justify-between pt-1">
                    <span className="text-xs font-semibold uppercase tracking-[0.14em] text-white">
                      {slide.ctaLabel}
                    </span>
                    <span
                      className={`flex h-9 w-9 items-center justify-center border transition-colors ${
                        isActive
                          ? 'border-white bg-white text-[#080809]'
                          : 'border-white/20 text-white'
                      }`}
                    >
                      <ArrowUpRight className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Minimal Dots Only (no bottom labels, no arrows) */}
      <div className="flex items-center justify-center gap-2 pt-2">
        {SLIDES.map((s, idx) => {
          const active = idx === clampedIndex;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => goTo(idx)}
              aria-label={s.title}
              className={`h-[2px] transition-all duration-200 ${
                active ? 'w-6 bg-white' : 'w-2 bg-white/25 hover:bg-white/50'
              }`}
            />
          );
        })}
      </div>
    </div>
  );
}
