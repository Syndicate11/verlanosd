import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, CheckCircle2, RefreshCw } from 'lucide-react';
import { getTelegramWebApp } from '../lib/api';
import type { SubscriptionCheckResult } from '../types/store';

interface SubscriptionGateProps {
  subscription: SubscriptionCheckResult;
  onCheck: () => Promise<void>;
  onDemoConfirm: () => Promise<void>;
}

export function SubscriptionGate({
  subscription,
  onCheck,
  onDemoConfirm,
}: SubscriptionGateProps) {
  const [checking, setChecking] = useState(false);

  const handleOpenChannel = () => {
    const tg = getTelegramWebApp();
    if (tg?.openTelegramLink && subscription.channelUrl.startsWith('https://t.me/')) {
      tg.openTelegramLink(subscription.channelUrl);
    } else {
      window.open(subscription.channelUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleVerify = async () => {
    setChecking(true);
    try {
      await onCheck();
    } finally {
      setChecking(false);
    }
  };

  const handleDemo = async () => {
    setChecking(true);
    try {
      await onDemoConfirm();
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#080809] px-5 py-10">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md border border-white/[0.12] bg-[#0E0E10] p-6 sm:p-8"
      >
        <div className="border-b border-white/[0.08] pb-5">
          <p className="text-xs text-[#8A8A8E]">Обязательная подписка</p>
          <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-white">
            Канал Verlano
          </h2>
        </div>

        <p className="mt-5 text-sm leading-relaxed text-[#8A8A8E]">
          Чтобы открыть магазин <span className="text-white">Verlano</span>, подпишитесь на наш
          официальный канал. Там публикуются новые дропы, наличие размеров и закрытые промокоды.
        </p>

        {subscription.message && (
          <div className="mt-4 border border-white/20 bg-[#080809] px-4 py-3 text-xs leading-relaxed text-white">
            {subscription.message}
          </div>
        )}

        <div className="mt-6 flex flex-col gap-3">
          <button
            type="button"
            onClick={handleOpenChannel}
            className="flex min-h-[48px] w-full items-center justify-between border border-white/20 bg-[#141416] px-4 py-3 text-xs font-medium uppercase tracking-[0.12em] text-white transition-colors hover:border-white/50 active:scale-[0.99]"
          >
            <span>1. Подписаться на канал</span>
            <ArrowUpRight className="h-4 w-4 text-white" />
          </button>

          <button
            type="button"
            onClick={handleVerify}
            disabled={checking}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/85 active:scale-[0.99] disabled:opacity-60"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${checking ? 'animate-spin' : ''}`} />
            <span>2. Проверить подписку</span>
          </button>

          {subscription.mode === 'demo' && (
            <div className="mt-3 border-t border-white/[0.08] pt-4">
              <p className="mb-3 text-xs leading-relaxed text-[#8A8A8E]">
                Предпросмотр открыт в браузере вне Telegram. Подтвердите демо-доступ, чтобы перейти в
                магазин.
              </p>
              <button
                type="button"
                onClick={handleDemo}
                disabled={checking}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 border border-white/[0.14] bg-transparent px-4 py-2.5 text-xs font-medium text-white transition-colors hover:border-white/35 active:scale-[0.99]"
              >
                <CheckCircle2 className="h-4 w-4 text-white" />
                <span>Открыть демо-режим</span>
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
