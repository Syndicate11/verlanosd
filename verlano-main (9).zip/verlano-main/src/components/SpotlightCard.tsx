import React from 'react';
import { motion } from 'motion/react';

interface SpotlightCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  asButton?: boolean;
  disabled?: boolean;
}

export function SpotlightCard({
  children,
  className = '',
  onClick,
  asButton = false,
  disabled = false,
}: SpotlightCardProps) {
  return (
    <motion.div
      onClick={!disabled ? onClick : undefined}
      role={asButton ? 'button' : undefined}
      tabIndex={asButton && !disabled ? 0 : undefined}
      onKeyDown={
        asButton && !disabled
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick?.();
              }
            }
          : undefined
      }
      whileTap={asButton && !disabled ? { scale: 0.988 } : undefined}
      transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
      className={`group relative overflow-hidden rounded-[2px] border border-white/[0.1] bg-[#0E0E10] transition-colors duration-200 ${
        asButton && !disabled ? 'cursor-pointer hover:border-white/40' : ''
      } ${className}`}
    >
      <div className="relative z-10 h-full">{children}</div>
    </motion.div>
  );
}

