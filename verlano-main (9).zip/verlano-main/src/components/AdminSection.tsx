import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Check,
  ImagePlus,
  KeyRound,
  LogOut,
  Package,
  Pencil,
  Plus,
  Settings,
  ShieldCheck,
  Tag,
  Terminal,
  Trash2,
  X,
} from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import {
  adminCreateProduct,
  adminCreatePromo,
  adminDeleteProduct,
  adminDeletePromo,
  adminTogglePromo,
  adminUpdateOrderStatus,
  adminUpdateProduct,
  adminUpdateSettings,
  fetchAdminOverview,
  fetchAdminStatus,
  formatPrice,
  loginAdmin,
  ORDER_STATUS_TEXT,
  setupAdminAccount,
} from '../lib/api';
import type {
  CategoryKey,
  CategoryMeta,
  Order,
  OrderStatus,
  Product,
  PromoCode,
  StoreSettings,
} from '../types/store';

interface AdminSectionProps {
  onDataChanged: () => Promise<void>;
  currentUserId: string;
}

type AdminTab = 'orders' | 'products' | 'promos' | 'settings';

const DEFAULT_CATEGORIES: Record<CategoryKey, CategoryMeta> = {
  ziphoodies: {
    title: 'Зип-худи',
    subtitle: 'Плотный футер и двусторонняя фурнитура',
  },
  tshirts: {
    title: 'Футболки',
    subtitle: 'Плотный трикотаж 320 г/м² и свободный крой',
  },
  pants: {
    title: 'Брюки',
    subtitle: 'Архитектурный силуэт и костюмная ткань',
  },
};

const STUDIO_PRESETS: Array<{ label: string; url: string }> = [
  {
    label: 'Черная футболка (студия)',
    url: '/src/assets/images/verlano_tee_heavy_1795540088982.jpg',
  },
  {
    label: 'Пепельная футболка (студия)',
    url: '/src/assets/images/verlano_tee_ash_1795540090249.jpg',
  },
  {
    label: 'Карго брюки (студия)',
    url: '/src/assets/images/verlano_pants_cargo_1795540090502.jpg',
  },
  {
    label: 'Широкие брюки (студия)',
    url: '/src/assets/images/verlano_pants_wide_1795540091056.jpg',
  },
  {
    label: 'Черное зип-худи (студия)',
    url: '/src/assets/images/verlano_zip_obsidian_1795540091733.jpg',
  },
  {
    label: 'Графитовое зип-худи (студия)',
    url: '/src/assets/images/verlano_zip_slate_1795540091539.jpg',
  },
];

function resizeProductImageToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Выберите файл изображения (PNG, JPG или WebP)'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 960;
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Не удалось обработать изображение'));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => reject(new Error('Ошибка чтения изображения'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsDataURL(file);
  });
}

function emptyProductForm() {
  return {
    category: 'ziphoodies' as CategoryKey,
    name: '',
    subtitle: '',
    description: '',
    material: '100% хлопок · 320 г/м²',
    fit: 'Oversize Boxy',
    price: '5500',
    imageUrl: STUDIO_PRESETS[4].url,
    stockS: '5',
    stockM: '10',
    stockL: '8',
    stockXL: '4',
  };
}

export function AdminSection({ onDataChanged, currentUserId }: AdminSectionProps) {
  const [token, setToken] = useState<string | null>(null);
  const [adminIdDisplay, setAdminIdDisplay] = useState('');
  const [statusLoading, setStatusLoading] = useState(true);
  const [authStatus, setAuthStatus] = useState<{
    envConfigured: boolean;
    claimed: boolean;
    allowedIdsConfigured: boolean;
  }>({ envConfigured: false, claimed: false, allowedIdsConfigured: false });

  const [loginForm, setLoginForm] = useState({
    adminId: currentUserId || '',
    password: '',
  });
  const [authError, setAuthError] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);
  const [settingsForm, setSettingsForm] = useState<StoreSettings>({
    brandName: 'Verlano',
    channelUsername: '@verlano_news',
    channelUrl: 'https://t.me/verlano_news',
    botUsername: '@verlano_shop_bot',
    categories: DEFAULT_CATEGORIES,
  });
  const [botConfigured, setBotConfigured] = useState(false);
  const [overviewError, setOverviewError] = useState('');
  const [actionNotice, setActionNotice] = useState('');

  // Create / Edit Product Form
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState(emptyProductForm);
  const [productSubmitting, setProductSubmitting] = useState(false);
  const [productError, setProductError] = useState('');

  // New Promo Form
  const [newPromo, setNewPromo] = useState({
    code: '',
    discountPercent: '15',
    minOrderAmount: '5000',
    isPublic: true,
    description: '',
  });

  useEffect(() => {
    let mounted = true;
    fetchAdminStatus()
      .then((res) => {
        if (mounted) {
          setAuthStatus(res);
          setStatusLoading(false);
        }
      })
      .catch(() => {
        if (mounted) setStatusLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const loadOverview = useCallback(async (authToken: string) => {
    setOverviewError('');
    try {
      const data = await fetchAdminOverview(authToken);
      setOrders(data.orders);
      setProducts(data.products);
      setPromoCodes(data.promoCodes);
      setSettingsForm({
        ...data.settings,
        categories: {
          ziphoodies: {
            ...DEFAULT_CATEGORIES.ziphoodies,
            ...(data.settings.categories?.ziphoodies || {}),
          },
          tshirts: {
            ...DEFAULT_CATEGORIES.tshirts,
            ...(data.settings.categories?.tshirts || {}),
          },
          pants: {
            ...DEFAULT_CATEGORIES.pants,
            ...(data.settings.categories?.pants || {}),
          },
        },
      });
      setBotConfigured(data.botConfigured);
    } catch (err) {
      setOverviewError(err instanceof Error ? err.message : 'Ошибка загрузки админ-данных');
    }
  }, []);

  const flashNotice = (text: string) => {
    setActionNotice(text);
    setTimeout(() => setActionNotice(''), 2500);
  };

  const needsFirstRunClaim = !authStatus.envConfigured && !authStatus.claimed;

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = needsFirstRunClaim
        ? await setupAdminAccount(loginForm.adminId, loginForm.password)
        : await loginAdmin(loginForm.adminId, loginForm.password);
      setToken(res.token);
      setAdminIdDisplay(res.adminId);
      setLoginForm((p) => ({ ...p, password: '' }));
      await loadOverview(res.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Ошибка входа');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleStatusChange = async (orderId: string, status: OrderStatus) => {
    if (!token) return;
    await adminUpdateOrderStatus(token, orderId, status);
    await loadOverview(token);
    await onDataChanged();
    flashNotice('Статус заказа обновлён');
  };

  const handleProductImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProductError('');
    try {
      const dataUrl = await resizeProductImageToDataUrl(file);
      setProductForm((prev) => ({ ...prev, imageUrl: dataUrl }));
    } catch (err) {
      setProductError(err instanceof Error ? err.message : 'Не удалось загрузить фото');
    } finally {
      e.target.value = '';
    }
  };

  const handleStartEditProduct = (product: Product) => {
    const findStock = (size: 'S' | 'M' | 'L' | 'XL') =>
      String(product.sizes.find((s) => s.size === size)?.stock ?? 0);

    setEditingProductId(product.id);
    setProductError('');
    setProductForm({
      category: product.category,
      name: product.name,
      subtitle: product.subtitle || '',
      description: product.description || '',
      material: product.material || '',
      fit: product.fit || '',
      price: String(product.price),
      imageUrl: product.imageUrl,
      stockS: findStock('S'),
      stockM: findStock('M'),
      stockL: findStock('L'),
      stockXL: findStock('XL'),
    });
  };

  const handleCancelEditProduct = () => {
    setEditingProductId(null);
    setProductError('');
    setProductForm(emptyProductForm());
  };

  const handleSubmitProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setProductError('');
    setProductSubmitting(true);
    try {
      const payload = {
        category: productForm.category,
        name: productForm.name,
        subtitle: productForm.subtitle,
        description: productForm.description,
        material: productForm.material,
        fit: productForm.fit,
        price: Number(productForm.price),
        imageUrl: productForm.imageUrl,
        sizes: [
          { size: 'S', stock: Number(productForm.stockS) || 0 },
          { size: 'M', stock: Number(productForm.stockM) || 0 },
          { size: 'L', stock: Number(productForm.stockL) || 0 },
          { size: 'XL', stock: Number(productForm.stockXL) || 0 },
        ],
      };

      if (editingProductId) {
        await adminUpdateProduct(token, editingProductId, payload);
        setEditingProductId(null);
        setProductForm(emptyProductForm());
        flashNotice('Товар обновлён');
      } else {
        await adminCreateProduct(token, payload);
        setProductForm(emptyProductForm());
        flashNotice('Товар добавлен в каталог');
      }
      await loadOverview(token);
      await onDataChanged();
    } catch (err) {
      setProductError(err instanceof Error ? err.message : 'Ошибка сохранения товара');
    } finally {
      setProductSubmitting(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!token) return;
    await adminDeleteProduct(token, productId);
    if (editingProductId === productId) {
      handleCancelEditProduct();
    }
    await loadOverview(token);
    await onDataChanged();
    flashNotice('Товар удалён');
  };

  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    await adminCreatePromo(token, {
      code: newPromo.code,
      discountPercent: Number(newPromo.discountPercent),
      minOrderAmount: Number(newPromo.minOrderAmount),
      isPublic: newPromo.isPublic,
      description: newPromo.description,
    });
    setNewPromo({
      code: '',
      discountPercent: '15',
      minOrderAmount: '5000',
      isPublic: true,
      description: '',
    });
    await loadOverview(token);
    await onDataChanged();
    flashNotice('Промокод создан');
  };

  const handleTogglePromo = async (promo: PromoCode, field: 'active' | 'isPublic') => {
    if (!token) return;
    await adminTogglePromo(token, promo.id, { [field]: !promo[field] });
    await loadOverview(token);
    await onDataChanged();
  };

  const handleDeletePromo = async (promoId: string) => {
    if (!token) return;
    await adminDeletePromo(token, promoId);
    await loadOverview(token);
    await onDataChanged();
    flashNotice('Промокод удалён');
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    await adminUpdateSettings(token, settingsForm);
    await loadOverview(token);
    await onDataChanged();
    flashNotice('Настройки сохранены');
  };

  const categoriesMap = settingsForm.categories || DEFAULT_CATEGORIES;

  const updateCategoryField = (
    key: CategoryKey,
    field: 'title' | 'subtitle',
    value: string
  ) => {
    setSettingsForm((prev) => {
      const current = prev.categories || DEFAULT_CATEGORIES;
      return {
        ...prev,
        categories: {
          ...current,
          [key]: {
            ...current[key],
            [field]: value,
          },
        },
      };
    });
  };

  if (!token) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="mx-auto max-w-md py-4"
      >
        <SpotlightCard className="p-6 sm:p-8">
          <div className="mb-6 flex items-center gap-3 border-b border-white/10 pb-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-[2px] border border-white/15 bg-[#141417]">
              <KeyRound className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-[#8A8A8E]">
                Служебный доступ
              </p>
              <h2 className="font-display text-2xl font-medium text-[#F5F5F5]">
                {needsFirstRunClaim ? 'Активация админ-панели' : 'Вход в админ-панель'}
              </h2>
            </div>
          </div>

          {statusLoading ? (
            <p className="py-6 text-center text-sm text-[#8A8A8E]">Проверка конфигурации...</p>
          ) : (
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {needsFirstRunClaim && (
                <div className="rounded-[2px] border border-white/20 bg-white/[0.05] p-3.5 text-xs leading-relaxed text-[#F5F5F5]">
                  Первый запуск: переменная окружения <span className="font-mono">ADMIN_PASSWORD</span> не
                  задана. Укажите ваш Telegram ID и задайте пароль администратора.
                </div>
              )}

              <label className="block space-y-1.5">
                <span className="text-xs text-[#8A8A8E]">ID администратора (Telegram ID)</span>
                <input
                  type="text"
                  value={loginForm.adminId}
                  onChange={(e) => setLoginForm((p) => ({ ...p, adminId: e.target.value }))}
                  placeholder="Например: 123456789"
                  required
                  className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="text-xs text-[#8A8A8E]">
                  {needsFirstRunClaim ? 'Задайте пароль администратора' : 'Пароль администратора'}
                </span>
                <input
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm((p) => ({ ...p, password: e.target.value }))}
                  placeholder="••••••••••"
                  required
                  className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
                />
              </label>

              {authError && (
                <p className="border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
                  {authError}
                </p>
              )}

              <button
                type="submit"
                disabled={authSubmitting}
                className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-[2px] bg-white px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90 disabled:opacity-60"
              >
                <ShieldCheck className="h-4 w-4" />
                <span>
                  {authSubmitting
                    ? 'Проверка...'
                    : needsFirstRunClaim
                    ? 'Активировать и войти'
                    : 'Войти в панель'}
                </span>
              </button>
            </form>
          )}
        </SpotlightCard>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <p className="font-mono text-xs text-[#8A8A8E]">Admin ID: {adminIdDisplay}</p>
          <h2 className="font-display mt-1 text-3xl font-medium tracking-tight text-[#F5F5F5]">
            Админ-панель Verlano
          </h2>
        </div>

        <div className="flex items-center gap-3">
          {actionNotice && (
            <span className="inline-flex items-center gap-1.5 border border-white/20 bg-white/[0.06] px-2.5 py-1 text-xs text-white">
              <Check className="h-3.5 w-3.5" />
              <span>{actionNotice}</span>
            </span>
          )}
          <button
            type="button"
            onClick={() => setToken(null)}
            className="flex min-h-[40px] items-center gap-2 rounded-[2px] border border-white/15 bg-[#141417] px-3.5 py-2 text-xs font-medium text-[#F5F5F5] transition-colors hover:border-white/35"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Выйти</span>
          </button>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'orders', label: `Заказы (${orders.length})`, icon: Package },
            { id: 'products', label: `Товары (${products.length})`, icon: Plus },
            { id: 'promos', label: `Промокоды (${promoCodes.length})`, icon: Tag },
            { id: 'settings', label: 'Настройки', icon: Settings },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`flex min-h-[42px] items-center gap-2 rounded-[2px] border px-4 py-2 text-xs font-medium transition-all whitespace-nowrap ${
                active
                  ? 'border-white bg-white text-[#080809]'
                  : 'border-white/15 bg-[#141417] text-[#F5F5F5] hover:border-white/35'
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {overviewError && (
        <p className="border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
          {overviewError}
        </p>
      )}

      {/* Tab: Orders */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <SpotlightCard className="p-10 text-center">
              <p className="text-sm text-[#8A8A8E]">Пока нет поступивших заказов</p>
            </SpotlightCard>
          ) : (
            orders.map((order) => (
              <SpotlightCard key={order.id} className="p-5">
                <div className="flex flex-col justify-between gap-4 border-b border-white/10 pb-4 sm:flex-row sm:items-center">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-sm font-semibold text-[#F5F5F5]">
                        {order.orderNumber}
                      </span>
                      <span className="text-xs text-[#8A8A8E]">
                        {new Date(order.createdAt).toLocaleString('ru-RU')}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-[#8A8A8E]">
                      {order.customerSnapshot.firstName} {order.customerSnapshot.lastName} (@
                      {order.customerSnapshot.nickname}) · {order.customerSnapshot.phone}
                    </p>
                    <p className="mt-0.5 text-xs text-[#F5F5F5]">
                      Адрес: {order.customerSnapshot.address}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-mono text-base font-semibold text-[#F5F5F5] tabular-nums">
                      {formatPrice(order.totalAmount)}
                    </span>
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                      className="rounded-[2px] border border-white/15 bg-[#080809] px-3 py-2 text-xs text-[#F5F5F5] outline-none focus:border-white/45"
                    >
                      {(Object.keys(ORDER_STATUS_TEXT) as OrderStatus[]).map((st) => (
                        <option key={st} value={st}>
                          {ORDER_STATUS_TEXT[st]}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mt-3 space-y-1 text-xs text-[#8A8A8E]">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between">
                      <span>
                        {item.name} [{item.size}] × {item.quantity}
                      </span>
                      <span className="font-mono tabular-nums">
                        {formatPrice(item.unitPrice * item.quantity)}
                      </span>
                    </div>
                  ))}
                  {order.promoCode && (
                    <div className="flex justify-between text-white">
                      <span>Промокод {order.promoCode}</span>
                      <span className="font-mono tabular-nums">
                        -{formatPrice(order.discountAmount)}
                      </span>
                    </div>
                  )}
                </div>
              </SpotlightCard>
            ))
          )}
        </div>
      )}

      {/* Tab: Products */}
      {activeTab === 'products' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <SpotlightCard className="p-6 lg:col-span-5">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-semibold text-[#F5F5F5]">
                {editingProductId ? 'Редактировать товар' : 'Добавить позицию'}
              </h3>
              {editingProductId && (
                <button
                  type="button"
                  onClick={handleCancelEditProduct}
                  className="inline-flex items-center gap-1 text-xs text-[#8A8A8E] hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                  <span>Отмена</span>
                </button>
              )}
            </div>

            <form onSubmit={handleSubmitProduct} className="mt-4 space-y-3">
              <select
                value={productForm.category}
                onChange={(e) =>
                  setProductForm((p) => ({ ...p, category: e.target.value as CategoryKey }))
                }
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] outline-none focus:border-white/45"
              >
                <option value="ziphoodies">{categoriesMap.ziphoodies.title}</option>
                <option value="tshirts">{categoriesMap.tshirts.title}</option>
                <option value="pants">{categoriesMap.pants.title}</option>
              </select>

              <input
                type="text"
                required
                value={productForm.name}
                onChange={(e) => setProductForm((p) => ({ ...p, name: e.target.value }))}
                placeholder="Название модели (например: Verlano Void Tee)"
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />

              <input
                type="text"
                value={productForm.subtitle}
                onChange={(e) => setProductForm((p) => ({ ...p, subtitle: e.target.value }))}
                placeholder="Краткий подзаголовок"
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />

              <textarea
                rows={3}
                value={productForm.description}
                onChange={(e) => setProductForm((p) => ({ ...p, description: e.target.value }))}
                placeholder="Описание товара (крой, детали, плотность ткани)"
                className="w-full resize-y rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />

              <div className="grid grid-cols-2 gap-3">
                <input
                  type="number"
                  required
                  min={100}
                  value={productForm.price}
                  onChange={(e) => setProductForm((p) => ({ ...p, price: e.target.value }))}
                  placeholder="Цена ₽"
                  className="rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                />
                <input
                  type="text"
                  value={productForm.fit}
                  onChange={(e) => setProductForm((p) => ({ ...p, fit: e.target.value }))}
                  placeholder="Посадка"
                  className="rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                />
              </div>

              <input
                type="text"
                value={productForm.material}
                onChange={(e) => setProductForm((p) => ({ ...p, material: e.target.value }))}
                placeholder="Материал (например: 100% хлопок · 320 г/м²)"
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />

              {/* Фото товара: загрузка файла + превью + выбор шаблона */}
              <div className="space-y-2.5 rounded-[2px] border border-white/15 bg-[#080809] p-3">
                <div className="flex items-center gap-3">
                  <div className="h-14 w-14 shrink-0 overflow-hidden border border-white/15 bg-[#141417]">
                    <img
                      src={productForm.imageUrl}
                      alt="Превью товара"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <label className="inline-flex min-h-[36px] cursor-pointer items-center gap-2 border border-white/20 bg-[#141417] px-3 py-1.5 text-xs font-medium text-[#F5F5F5] transition-colors hover:border-white/45">
                      <ImagePlus className="h-3.5 w-3.5 text-white" />
                      <span>Загрузить фото с устройства</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        onChange={handleProductImageUpload}
                        className="hidden"
                      />
                    </label>
                    <p className="truncate font-mono text-[10px] text-[#8A8A8E]">
                      {productForm.imageUrl.startsWith('data:')
                        ? 'Загружено своё фото'
                        : productForm.imageUrl}
                    </p>
                  </div>
                </div>

                <select
                  value={
                    STUDIO_PRESETS.some((p) => p.url === productForm.imageUrl)
                      ? productForm.imageUrl
                      : ''
                  }
                  onChange={(e) => {
                    if (e.target.value) {
                      setProductForm((p) => ({ ...p, imageUrl: e.target.value }));
                    }
                  }}
                  className="w-full rounded-[2px] border border-white/10 bg-[#141417] px-3 py-2 text-xs text-[#F5F5F5] outline-none"
                >
                  <option value="">Или выберите готовое фото из студии...</option>
                  {STUDIO_PRESETS.map((preset) => (
                    <option key={preset.url} value={preset.url}>
                      {preset.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {(
                  [
                    ['S', 'stockS'],
                    ['M', 'stockM'],
                    ['L', 'stockL'],
                    ['XL', 'stockXL'],
                  ] as const
                ).map(([label, key]) => (
                  <label key={key} className="block space-y-1 text-center">
                    <span className="font-mono text-[11px] text-[#8A8A8E]">{label}</span>
                    <input
                      type="number"
                      min={0}
                      value={productForm[key]}
                      onChange={(e) => setProductForm((p) => ({ ...p, [key]: e.target.value }))}
                      className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-2 py-1.5 text-center font-mono text-xs text-[#F5F5F5] outline-none focus:border-white/45"
                    />
                  </label>
                ))}
              </div>

              {productError && (
                <p className="border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
                  {productError}
                </p>
              )}

              <button
                type="submit"
                disabled={productSubmitting}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[2px] bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90 disabled:opacity-60"
              >
                {editingProductId ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                <span>
                  {productSubmitting
                    ? 'Сохранение...'
                    : editingProductId
                    ? 'Сохранить изменения'
                    : 'Добавить в каталог'}
                </span>
              </button>
            </form>
          </SpotlightCard>

          <div className="space-y-3 lg:col-span-7">
            {products.map((product) => {
              const isEditing = editingProductId === product.id;
              return (
                <SpotlightCard
                  key={product.id}
                  className={`p-4 ${isEditing ? 'border-white/45' : ''}`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex min-w-0 items-center gap-3.5">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="h-14 w-16 shrink-0 rounded-[2px] border border-white/10 object-cover"
                      />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="truncate text-sm font-semibold text-[#F5F5F5]">
                            {product.name}
                          </p>
                          <span className="border border-white/15 px-1.5 py-0.5 font-mono text-[10px] text-[#8A8A8E]">
                            {categoriesMap[product.category]?.title || product.category}
                          </span>
                        </div>
                        <p className="mt-0.5 font-mono text-xs text-[#8A8A8E] tabular-nums">
                          {formatPrice(product.price)} ·{' '}
                          {product.sizes.map((s) => `${s.size}:${s.stock}`).join(' ')}
                        </p>
                        {product.description && (
                          <p className="mt-1 line-clamp-1 text-xs text-[#8A8A8E]">
                            {product.description}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex shrink-0 items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleStartEditProduct(product)}
                        aria-label="Редактировать товар"
                        className="flex h-9 w-9 items-center justify-center rounded-[2px] border border-white/15 text-[#F5F5F5] transition-colors hover:border-white/45 hover:bg-white/10"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteProduct(product.id)}
                        aria-label="Удалить товар"
                        className="flex h-9 w-9 items-center justify-center rounded-[2px] border border-white/15 text-[#A1A1AA] transition-colors hover:border-white/45 hover:bg-white/10 hover:text-white"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </SpotlightCard>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab: Promo Codes */}
      {activeTab === 'promos' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <SpotlightCard className="p-6 lg:col-span-5">
            <h3 className="text-base font-semibold text-[#F5F5F5]">Создать промокод</h3>
            <form onSubmit={handleCreatePromo} className="mt-4 space-y-3">
              <input
                type="text"
                required
                value={newPromo.code}
                onChange={(e) =>
                  setNewPromo((p) => ({ ...p, code: e.target.value.toUpperCase() }))
                }
                placeholder="Код (например: VERLANO20)"
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm uppercase text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="number"
                  required
                  min={1}
                  max={90}
                  value={newPromo.discountPercent}
                  onChange={(e) => setNewPromo((p) => ({ ...p, discountPercent: e.target.value }))}
                  placeholder="Скидка %"
                  className="rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                />
                <input
                  type="number"
                  min={0}
                  value={newPromo.minOrderAmount}
                  onChange={(e) => setNewPromo((p) => ({ ...p, minOrderAmount: e.target.value }))}
                  placeholder="Мин. сумма ₽"
                  className="rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                />
              </div>
              <input
                type="text"
                value={newPromo.description}
                onChange={(e) => setNewPromo((p) => ({ ...p, description: e.target.value }))}
                placeholder="Описание для покупателей"
                className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
              />
              <label className="flex items-center gap-2.5 text-xs text-[#F5F5F5]">
                <input
                  type="checkbox"
                  checked={newPromo.isPublic}
                  onChange={(e) => setNewPromo((p) => ({ ...p, isPublic: e.target.checked }))}
                  className="h-4 w-4 rounded border-white/25 bg-[#080809] accent-white"
                />
                <span>Показывать всем в разделе «Промокоды»</span>
              </label>
              <button
                type="submit"
                className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[2px] bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90"
              >
                <Plus className="h-4 w-4" />
                <span>Создать промокод</span>
              </button>
            </form>
          </SpotlightCard>

          <div className="space-y-3 lg:col-span-7">
            {promoCodes.map((promo) => (
              <SpotlightCard key={promo.id} className="p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-sm font-semibold text-[#F5F5F5]">
                        {promo.code}
                      </span>
                      <span className="font-mono text-xs text-white tabular-nums">
                        -{promo.discountPercent}%
                      </span>
                      <span className="text-xs text-[#8A8A8E]">
                        · {promo.isPublic ? 'Публичный' : 'Скрытый'}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-[#8A8A8E]">{promo.description}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleTogglePromo(promo, 'isPublic')}
                      className="rounded-[2px] border border-white/15 bg-[#141417] px-3 py-1.5 text-xs text-[#F5F5F5] hover:border-white/35"
                    >
                      {promo.isPublic ? 'Скрыть' : 'Для всех'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleTogglePromo(promo, 'active')}
                      className={`rounded-[2px] border px-3 py-1.5 text-xs ${
                        promo.active
                          ? 'border-white/40 bg-white/15 text-white'
                          : 'border-white/10 bg-[#141417] text-[#8A8A8E]'
                      }`}
                    >
                      {promo.active ? 'Активен' : 'Выключен'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeletePromo(promo.id)}
                      aria-label="Удалить промокод"
                      className="flex h-8 w-8 items-center justify-center rounded-[2px] border border-white/15 text-[#A1A1AA] hover:border-white/40 hover:bg-white/10 hover:text-white"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </SpotlightCard>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Settings */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <SpotlightCard className="p-6 lg:col-span-6">
            <h3 className="text-base font-semibold text-[#F5F5F5]">
              Категории в разделе «Заказать» и канал
            </h3>
            <p className="mt-1 text-xs text-[#8A8A8E]">
              Статус токена на сервере:{' '}
              <span className="text-[#F5F5F5]">
                {botConfigured ? 'TELEGRAM_BOT_TOKEN подключён' : 'Демо-режим (токен не задан)'}
              </span>
            </p>

            <form onSubmit={handleSaveSettings} className="mt-4 space-y-5">
              <div className="space-y-3 border-b border-white/10 pb-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
                  Названия категорий каталога
                </p>
                {(['ziphoodies', 'tshirts', 'pants'] as const).map((key, idx) => (
                  <div
                    key={key}
                    className="space-y-2 rounded-[2px] border border-white/10 bg-[#080809] p-3"
                  >
                    <span className="font-mono text-[10px] uppercase tracking-wider text-[#8A8A8E]">
                      Категория 0{idx + 1}
                    </span>
                    <input
                      type="text"
                      required
                      value={categoriesMap[key].title}
                      onChange={(e) => updateCategoryField(key, 'title', e.target.value)}
                      placeholder="Название категории"
                      className="w-full rounded-[2px] border border-white/15 bg-[#141417] px-3 py-2 text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                    />
                    <input
                      type="text"
                      value={categoriesMap[key].subtitle}
                      onChange={(e) => updateCategoryField(key, 'subtitle', e.target.value)}
                      placeholder="Краткое описание категории"
                      className="w-full rounded-[2px] border border-white/15 bg-[#141417] px-3 py-2 text-xs text-[#F5F5F5] outline-none focus:border-white/45"
                    />
                  </div>
                ))}
              </div>

              <div className="space-y-3">
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
                  Канал и Telegram-бот
                </p>
                <label className="block space-y-1.5">
                  <span className="text-xs text-[#8A8A8E]">ID / @username новостного канала</span>
                  <input
                    type="text"
                    value={settingsForm.channelUsername}
                    onChange={(e) =>
                      setSettingsForm((p) => ({ ...p, channelUsername: e.target.value }))
                    }
                    className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                  />
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs text-[#8A8A8E]">Ссылка на новостной канал</span>
                  <input
                    type="url"
                    value={settingsForm.channelUrl}
                    onChange={(e) => setSettingsForm((p) => ({ ...p, channelUrl: e.target.value }))}
                    className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                  />
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs text-[#8A8A8E]">Username бота</span>
                  <input
                    type="text"
                    value={settingsForm.botUsername}
                    onChange={(e) => setSettingsForm((p) => ({ ...p, botUsername: e.target.value }))}
                    className="w-full rounded-[2px] border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] outline-none focus:border-white/45"
                  />
                </label>
              </div>

              <button
                type="submit"
                className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[2px] bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90"
              >
                <span>Сохранить настройки</span>
              </button>
            </form>
          </SpotlightCard>

          <SpotlightCard className="p-6 lg:col-span-6">
            <div className="mb-3 flex items-center gap-2">
              <Terminal className="h-4 w-4 text-white" />
              <h3 className="text-base font-semibold text-[#F5F5F5]">
                Запуск на сервере и обновление
              </h3>
            </div>
            <ol className="space-y-2.5 text-xs leading-relaxed text-[#8A8A8E]">
              <li>
                1. Проверьте файл <span className="font-mono text-[#F5F5F5]">.env</span>: укажите{' '}
                <span className="font-mono text-[#F5F5F5]">APP_URL</span>,{' '}
                <span className="font-mono text-[#F5F5F5]">TELEGRAM_BOT_TOKEN</span>,{' '}
                <span className="font-mono text-[#F5F5F5]">ADMIN_TELEGRAM_IDS</span> и{' '}
                <span className="font-mono text-[#F5F5F5]">ADMIN_PASSWORD</span>.
              </li>
              <li>
                2. Бот должен быть добавлен в администраторы канала, чтобы проверка подписки работала
                корректно.
              </li>
              <li>
                3. После обновления файлов на сервере выполните{' '}
                <span className="font-mono text-[#F5F5F5]">npm run build</span> и перезапустите{' '}
                <span className="font-mono text-[#F5F5F5]">pm2 restart verlano</span>.
              </li>
            </ol>
          </SpotlightCard>
        </div>
      )}
    </motion.div>
  );
}
