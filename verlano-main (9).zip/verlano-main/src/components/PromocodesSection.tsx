import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Tag } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import { formatPrice, validatePromoCode } from '../lib/api';
import type { PromoCode } from '../types/store';

interface PromocodesSectionProps {
  publicPromos: PromoCode[];
  appliedPromo: PromoCode | null;
  cartSubtotal: number;
  onApplyPromo: (promo: PromoCode) => void;
  onGoToCart: () => void;
}

export function PromocodesSection({
  publicPromos,
  appliedPromo,
  cartSubtotal,
  onApplyPromo,
  onGoToCart,
}: PromocodesSectionProps) {
  const [codeInput, setCodeInput] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setStatusMessage('');
    setLoading(true);
    try {
      const { promo } = await validatePromoCode(codeInput, cartSubtotal);
      onApplyPromo(promo);
      setStatusMessage(`Промокод ${promo.code} (-${promo.discountPercent}%) применён к корзине`);
      setCodeInput('');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Промокод недействителен');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="border-b border-white/10 pb-4">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#8A8A8E]">
          Скидки и акции
        </p>
        <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-[#F5F5F5] sm:text-4xl">
          Промокоды Verlano
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <SpotlightCard className="p-6 lg:col-span-5">
          <h3 className="font-display text-2xl font-medium text-[#F5F5F5]">Ввести код</h3>
          <p className="mt-1 text-xs text-[#8A8A8E]">
            Активируйте персональный или закрытый код из канала.
          </p>

          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <input
              type="text"
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
              placeholder="Введите код..."
              className="w-full border border-white/15 bg-[#080809] px-4 py-3 font-mono text-sm uppercase text-[#F5F5F5] placeholder-[#52525B] outline-none focus:border-white/45"
            />
            <button
              type="submit"
              disabled={loading || !codeInput.trim()}
              className="flex min-h-[46px] w-full items-center justify-center gap-2 bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90 disabled:opacity-50"
            >
              <Tag className="h-4 w-4" />
              <span>{loading ? 'Проверка...' : 'Активировать'}</span>
            </button>
          </form>

          {errorMessage && (
            <p className="mt-3 border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
              {errorMessage}
            </p>
          )}
          {statusMessage && (
            <div className="mt-3 flex items-center justify-between gap-2 border border-white/30 bg-white/[0.06] px-3.5 py-2.5 text-xs text-[#F5F5F5]">
              <span>{statusMessage}</span>
              <button
                type="button"
                onClick={onGoToCart}
                className="font-semibold text-white underline underline-offset-4 shrink-0"
              >
                В корзину
              </button>
            </div>
          )}
        </SpotlightCard>

        <SpotlightCard className="p-6 lg:col-span-7">
          <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-3.5">
            <div>
              <h3 className="font-display text-2xl font-medium text-[#F5F5F5]">Открытые коды</h3>
              <p className="mt-0.5 text-xs text-[#8A8A8E]">
                Активные предложения магазина Verlano
              </p>
            </div>
            <span className="font-mono text-xs text-white tabular-nums">
              {publicPromos.length}
            </span>
          </div>

          {publicPromos.length === 0 ? (
            <p className="py-8 text-center text-sm text-[#8A8A8E]">
              Сейчас нет открытых промокодов.
            </p>
          ) : (
            <div className="space-y-3">
              {publicPromos.map((promo) => {
                const isApplied = appliedPromo?.id === promo.id;
                return (
                  <div
                    key={promo.id}
                    className="flex flex-col justify-between gap-4 border border-white/10 bg-[#080809] p-4 sm:flex-row sm:items-center"
                  >
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-base font-medium tracking-wider text-[#F5F5F5]">
                          {promo.code}
                        </span>
                        <span className="font-mono text-xs font-medium text-white tabular-nums">
                          -{promo.discountPercent}%
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-[#8A8A8E]">{promo.description}</p>
                      {promo.minOrderAmount > 0 && (
                        <p className="mt-1 font-mono text-[11px] text-[#8A8A8E] tabular-nums">
                          От {formatPrice(promo.minOrderAmount)}
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onApplyPromo(promo)}
                      className={`flex min-h-[40px] items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-[0.12em] transition-colors whitespace-nowrap shrink-0 ${
                        isApplied
                          ? 'border border-white/40 bg-white/15 text-white'
                          : 'bg-white text-[#080809] hover:bg-white/90'
                      }`}
                    >
                      {isApplied && <Check className="h-3.5 w-3.5" />}
                      <span>{isApplied ? 'Применён' : 'Применить'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </SpotlightCard>
      </div>
    </motion.div>
  );
}
