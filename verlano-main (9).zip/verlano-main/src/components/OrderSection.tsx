import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, ArrowRight, Check, Lock, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import { formatPrice } from '../lib/api';
import type { CartEntry, CategoryKey, Product, StoreSettings } from '../types/store';

interface OrderSectionProps {
  products: Product[];
  cart: CartEntry[];
  settings: StoreSettings;
  selectedCategory: CategoryKey | null;
  selectedProductId: string | null;
  onSelectCategory: (category: CategoryKey) => void;
  onSelectProduct: (productId: string) => void;
  onBackStep: () => void;
  onAddToCart: (productId: string, size: 'S' | 'M' | 'L' | 'XL') => void;
  onUpdateCartQuantity: (productId: string, size: 'S' | 'M' | 'L' | 'XL', delta: number) => void;
  onRemoveFromCart: (productId: string, size: 'S' | 'M' | 'L' | 'XL') => void;
  onGoToCart: () => void;
}

const DEFAULT_CATEGORIES: Array<{
  key: CategoryKey;
  index: string;
  defaultTitle: string;
  defaultSubtitle: string;
  modelImageUrl: string;
  featuredSpan?: boolean;
}> = [
  {
    key: 'ziphoodies',
    index: '01',
    defaultTitle: 'Зип-худи',
    defaultSubtitle: 'Плотный футер 480–520 г/м² · Двойная молния',
    modelImageUrl: '/src/assets/images/cat_model_zip_1795557454525.jpg',
    featuredSpan: true,
  },
  {
    key: 'tshirts',
    index: '02',
    defaultTitle: 'Футболки',
    defaultSubtitle: 'Тяжелый хлопок · Свободный крой',
    modelImageUrl: '/src/assets/images/cat_model_tee_1795557453996.jpg',
  },
  {
    key: 'pants',
    index: '03',
    defaultTitle: 'Брюки',
    defaultSubtitle: 'Технические карго и широкие модели',
    modelImageUrl: '/src/assets/images/cat_model_pants_1795557454383.jpg',
  },
];

const UPCOMING_CATEGORIES = [
  {
    id: 'soon-longsleeves',
    title: 'Лонгсливы',
    subtitle: 'Вафельный трикотаж и удлинённый рукав',
  },
  {
    id: 'soon-outerwear',
    title: 'Верхняя одежда',
    subtitle: 'Утеплённые бомберы и технические куртки',
  },
  {
    id: 'soon-accessories',
    title: 'Аксессуары',
    subtitle: 'Сумки-слинги, кепки и металлические цепи',
  },
];

function ProductImage({
  src,
  alt,
  contain = false,
}: {
  src: string;
  alt: string;
  contain?: boolean;
}) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center bg-[#080809] p-4 text-center">
        <ShoppingBag className="mb-2 h-6 w-6 text-[#8A8A8E]" />
        <span className="text-xs text-[#8A8A8E]">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`h-full w-full transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03] ${
        contain ? 'object-contain p-4' : 'object-cover'
      }`}
    />
  );
}

export function OrderSection({
  products,
  cart,
  settings,
  selectedCategory,
  selectedProductId,
  onSelectCategory,
  onSelectProduct,
  onBackStep,
  onAddToCart,
  onUpdateCartQuantity,
  onRemoveFromCart,
  onGoToCart,
}: OrderSectionProps) {
  const [selectedSize, setSelectedSize] = useState<'S' | 'M' | 'L' | 'XL'>('M');

  const resolvedCategories = DEFAULT_CATEGORIES.map((cat) => {
    const custom = settings.categories?.[cat.key];
    return {
      ...cat,
      title: custom?.title || cat.defaultTitle,
      subtitle: custom?.subtitle || cat.defaultSubtitle,
    };
  });

  const selectedProduct = selectedProductId
    ? products.find((p) => p.id === selectedProductId) || null
    : null;

  useEffect(() => {
    if (selectedProduct) {
      const firstInStock = selectedProduct.sizes.find((s) => s.stock > 0)?.size || 'M';
      setSelectedSize(firstInStock);
    }
  }, [selectedProduct?.id]);

  const categoryProducts = selectedCategory
    ? products.filter((p) => p.category === selectedCategory)
    : [];

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (selectedProduct) {
    const sizeInfo = selectedProduct.sizes.find((s) => s.size === selectedSize);
    const inCartEntry = cart.find(
      (c) => c.productId === selectedProduct.id && c.size === selectedSize
    );
    const isOutOfStock = !sizeInfo || sizeInfo.stock <= 0;

    return (
      <motion.div
        key={`product-${selectedProduct.id}`}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="space-y-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onBackStep}
            className="flex min-h-[40px] items-center gap-2 border border-white/[0.14] bg-[#0E0E10] px-3.5 py-2 text-xs font-medium text-white transition-colors hover:border-white/40"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Все модели категории</span>
          </button>

          {totalCartItems > 0 && (
            <button
              type="button"
              onClick={onGoToCart}
              className="flex min-h-[40px] items-center gap-2 border border-white/25 bg-[#0E0E10] px-4 py-2 text-xs font-medium text-white transition-colors hover:border-white/60"
            >
              <ShoppingBag className="h-3.5 w-3.5 text-white" />
              <span className="tabular-nums">Перейти в корзину ({totalCartItems})</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
          <SpotlightCard className="lg:col-span-7">
            <div className="aspect-[4/3] w-full overflow-hidden bg-[#080809]">
              <ProductImage src={selectedProduct.imageUrl} alt={selectedProduct.name} />
            </div>
          </SpotlightCard>

          <SpotlightCard className="p-6 lg:col-span-5">
            <p className="text-xs text-[#8A8A8E]">{selectedProduct.subtitle}</p>
            <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-white">
              {selectedProduct.name}
            </h2>
            <p className="mt-3 font-mono text-2xl font-medium text-white tabular-nums">
              {formatPrice(selectedProduct.price)}
            </p>

            <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-[#8A8A8E]">
              {selectedProduct.description}
            </p>

            <div className="mt-5 grid grid-cols-2 gap-3 border-y border-white/[0.08] py-4 text-xs">
              <div>
                <span className="text-[#8A8A8E]">Материал</span>
                <p className="mt-1 font-medium text-white">{selectedProduct.material}</p>
              </div>
              <div>
                <span className="text-[#8A8A8E]">Посадка</span>
                <p className="mt-1 font-medium text-white">{selectedProduct.fit}</p>
              </div>
            </div>

            <div className="mt-5">
              <div className="mb-2.5 flex items-center justify-between text-xs">
                <span className="text-[#8A8A8E]">Размер</span>
                <span className="font-mono text-[#8A8A8E] tabular-nums">
                  {sizeInfo ? `В наличии: ${sizeInfo.stock} шт.` : 'Нет в наличии'}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {selectedProduct.sizes.map((s) => {
                  const active = s.size === selectedSize;
                  const unavailable = s.stock <= 0;
                  return (
                    <button
                      key={s.size}
                      type="button"
                      disabled={unavailable}
                      onClick={() => setSelectedSize(s.size)}
                      className={`min-h-[44px] border font-mono text-sm font-medium transition-colors ${
                        active
                          ? 'border-white bg-white text-[#080809]'
                          : unavailable
                          ? 'cursor-not-allowed border-white/[0.05] bg-[#0B0B0D] text-[#52525B] line-through'
                          : 'border-white/[0.14] bg-[#141416] text-white hover:border-white/45'
                      }`}
                    >
                      {s.size}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {!inCartEntry ? (
                <button
                  type="button"
                  disabled={isOutOfStock}
                  onClick={() => onAddToCart(selectedProduct.id, selectedSize)}
                  className="flex min-h-[48px] w-full items-center justify-center gap-2 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/85 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <ShoppingBag className="h-4 w-4" />
                  <span>{isOutOfStock ? 'Нет в наличии' : 'Добавить в корзину'}</span>
                </button>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between border border-white/[0.16] bg-[#141416] p-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateCartQuantity(selectedProduct.id, selectedSize, -1)
                      }
                      aria-label="Уменьшить количество"
                      className="flex h-10 w-10 items-center justify-center bg-[#080809] text-white transition-colors hover:bg-white/15"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <div className="text-center">
                      <span className="font-mono text-sm font-medium text-white tabular-nums">
                        {inCartEntry.quantity} шт. · {selectedSize}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={sizeInfo ? inCartEntry.quantity >= sizeInfo.stock : true}
                        onClick={() =>
                          onUpdateCartQuantity(selectedProduct.id, selectedSize, 1)
                        }
                        aria-label="Увеличить количество"
                        className="flex h-10 w-10 items-center justify-center bg-[#080809] text-white transition-colors hover:bg-white/15 disabled:opacity-40"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveFromCart(selectedProduct.id, selectedSize)}
                        aria-label="Удалить из корзины"
                        className="flex h-10 w-10 items-center justify-center bg-[#080809] text-white/75 transition-colors hover:bg-white/15 hover:text-white"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={onGoToCart}
                    className="flex min-h-[48px] w-full items-center justify-center gap-2 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/85 active:scale-[0.99]"
                  >
                    <Check className="h-4 w-4" />
                    <span>Перейти в корзину ({totalCartItems})</span>
                  </button>
                </div>
              )}
            </div>
          </SpotlightCard>
        </div>
      </motion.div>
    );
  }

  if (selectedCategory) {
    const activeCatMeta = resolvedCategories.find((c) => c.key === selectedCategory);
    return (
      <motion.div
        key={`category-${selectedCategory}`}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="space-y-6"
      >
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/[0.08] pb-5">
          <div>
            <button
              type="button"
              onClick={onBackStep}
              className="mb-3 flex min-h-[38px] items-center gap-2 border border-white/[0.14] bg-[#0E0E10] px-3.5 py-1.5 text-xs font-medium text-white transition-colors hover:border-white/40"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>К категориям</span>
            </button>
            <h2 className="font-display text-3xl font-medium tracking-tight text-white sm:text-4xl">
              {activeCatMeta?.title}
            </h2>
            <p className="mt-1 text-sm text-[#8A8A8E]">{activeCatMeta?.subtitle}</p>
          </div>
          <span className="font-mono text-xs text-white/80 tabular-nums">
            Моделей: {categoryProducts.length}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categoryProducts.map((product) => {
            const availableSizes = product.sizes
              .filter((s) => s.stock > 0)
              .map((s) => s.size)
              .join(' / ');

            return (
              <SpotlightCard
                key={product.id}
                asButton
                onClick={() => onSelectProduct(product.id)}
                className="flex flex-col"
              >
                <div className="aspect-[4/3] w-full overflow-hidden border-b border-white/[0.08] bg-[#080809]">
                  <ProductImage src={product.imageUrl} alt={product.name} />
                </div>
                <div className="flex flex-1 flex-col justify-between p-5">
                  <div>
                    <p className="text-xs text-[#8A8A8E]">{product.fit}</p>
                    <h3 className="font-display mt-1.5 text-2xl font-medium text-white">
                      {product.name}
                    </h3>
                    <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-[#8A8A8E]">
                      {product.description || product.material}
                    </p>
                  </div>
                  <div className="mt-5 flex items-center justify-between border-t border-white/[0.08] pt-3.5">
                    <span className="font-mono text-sm font-medium text-white tabular-nums">
                      {formatPrice(product.price)}
                    </span>
                    <span className="font-mono text-xs text-[#8A8A8E]">
                      {availableSizes || 'Нет в наличии'}
                    </span>
                  </div>
                </div>
              </SpotlightCard>
            );
          })}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      key="order-categories"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-8"
    >
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/[0.08] pb-5">
        <div>
          <p className="text-xs text-[#8A8A8E]">Каталог одежды</p>
          <h2 className="font-display mt-1 text-3xl font-medium tracking-tight text-white sm:text-4xl">
            Заказать
          </h2>
        </div>
        {totalCartItems > 0 && (
          <button
            type="button"
            onClick={onGoToCart}
            className="flex min-h-[42px] items-center gap-2 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-[#080809] transition-colors hover:bg-white/85"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            <span className="tabular-nums">Корзина ({totalCartItems})</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {resolvedCategories.map((cat) => {
          const items = products.filter((p) => p.category === cat.key);
          const minPrice = items.length > 0 ? Math.min(...items.map((i) => i.price)) : 0;

          return (
            <SpotlightCard
              key={cat.key}
              asButton
              onClick={() => onSelectCategory(cat.key)}
              className={cat.featuredSpan ? 'lg:col-span-6' : 'lg:col-span-3'}
            >
              <div className="flex h-full flex-col justify-between">
                <div
                  className={`relative overflow-hidden border-b border-white/[0.08] bg-[#080809] ${
                    cat.featuredSpan ? 'aspect-[16/10]' : 'aspect-[4/3]'
                  }`}
                >
                  <ProductImage src={cat.modelImageUrl} alt={cat.title} contain />
                  <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                    <span className="font-mono text-[11px] text-[#8A8A8E]">{cat.index}</span>
                    <span className="font-mono text-xs text-white/85 tabular-nums">
                      {items.length > 0 ? `${items.length} мод. · от ${formatPrice(minPrice)}` : 'Скоро'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-4 p-5">
                  <div>
                    <h3 className="font-display text-2xl font-medium text-white">{cat.title}</h3>
                    <p className="mt-1 text-xs text-[#8A8A8E]">{cat.subtitle}</p>
                  </div>
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-white/[0.16] bg-[#141416] text-white transition-colors group-hover:border-white group-hover:bg-white group-hover:text-[#080809]">
                    <ArrowRight className="h-4 w-4" />
                  </div>
                </div>
              </div>
            </SpotlightCard>
          );
        })}
      </div>

      <div className="border-t border-white/[0.08] pt-7">
        <div className="mb-4">
          <h3 className="font-display text-2xl font-medium text-white">Скоро в наличии</h3>
          <p className="mt-0.5 text-xs text-[#8A8A8E]">
            Новые категории находятся в разработке
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {UPCOMING_CATEGORIES.map((upcoming) => (
            <div
              key={upcoming.id}
              className="flex flex-col justify-between border border-white/[0.08] bg-[#0B0B0D] p-5 opacity-75"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex h-9 w-9 items-center justify-center border border-white/[0.1] bg-[#121214] text-[#8A8A8E]">
                  <Lock className="h-4 w-4" />
                </div>
                <span className="font-mono text-xs uppercase tracking-[0.16em] text-white/70">
                  Скоро
                </span>
              </div>
              <div className="mt-5">
                <h4 className="font-display text-xl font-medium text-white">{upcoming.title}</h4>
                <p className="mt-1 text-xs text-[#8A8A8E]">{upcoming.subtitle}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
