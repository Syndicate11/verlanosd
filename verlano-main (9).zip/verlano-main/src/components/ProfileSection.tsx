import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Camera, Check, Package, Save, User } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';
import { formatPrice, ORDER_STATUS_TEXT } from '../lib/api';
import type { CustomerProfile, Order } from '../types/store';

interface ProfileSectionProps {
  profile: CustomerProfile;
  orders: Order[];
  onSaveProfile: (payload: Partial<CustomerProfile>) => Promise<void>;
}

const PRESET_AVATARS = [
  'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" fill="#0E0E10"/><circle cx="60" cy="46" r="20" fill="#18181B" stroke="#FFFFFF" stroke-width="2"/><path d="M24 106c4-20 18-30 36-30s32 10 36 30" fill="#18181B" stroke="#FFFFFF" stroke-width="2"/></svg>'
    ),
  'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" fill="#080809"/><polygon points="60,18 98,88 22,88" fill="none" stroke="#FFFFFF" stroke-width="2.2"/><circle cx="60" cy="64" r="9" fill="#FFFFFF"/></svg>'
    ),
  'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" fill="#141417"/><rect x="28" y="28" width="64" height="64" fill="none" stroke="#FFFFFF" stroke-width="2"/><line x1="28" y1="92" x2="92" y2="28" stroke="#A1A1AA" stroke-width="2"/></svg>'
    ),
];

function resizeAvatarToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 256;
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Не удалось обработать изображение'));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.84));
      };
      img.onerror = () => reject(new Error('Ошибка чтения изображения'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsDataURL(file);
  });
}

export function ProfileSection({ profile, orders, onSaveProfile }: ProfileSectionProps) {
  const [form, setForm] = useState({
    nickname: profile.nickname || '',
    firstName: profile.firstName || '',
    lastName: profile.lastName || '',
    phone: profile.phone || '',
    address: profile.address || '',
    deliveryNote: profile.deliveryNote || '',
    avatarUrl: profile.avatarUrl || '',
  });
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const totalSpent = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const activeOrders = orders.filter((o) => o.status !== 'delivered').length;

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg('');
    try {
      const dataUrl = await resizeAvatarToDataUrl(file);
      setForm((prev) => ({ ...prev, avatarUrl: dataUrl }));
      await onSaveProfile({ ...form, avatarUrl: dataUrl });
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2200);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Не удалось загрузить аватар');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMsg('');
    try {
      await onSaveProfile(form);
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2200);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Ошибка сохранения профиля');
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="border-b border-white/10 pb-4">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#8A8A8E]">
          Личный кабинет
        </p>
        <h2 className="font-display mt-1.5 text-3xl font-medium tracking-tight text-[#F5F5F5] sm:text-4xl">
          Профиль покупателя
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <SpotlightCard className="p-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
            Всего заказов
          </p>
          <p className="mt-2 font-mono text-2xl font-medium text-[#F5F5F5] tabular-nums">
            {orders.length}
          </p>
        </SpotlightCard>
        <SpotlightCard className="p-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
            Сумма покупок
          </p>
          <p className="mt-2 font-mono text-2xl font-medium text-[#F5F5F5] tabular-nums">
            {formatPrice(totalSpent)}
          </p>
        </SpotlightCard>
        <SpotlightCard className="p-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-[#8A8A8E]">
            Активные доставки
          </p>
          <p className="mt-2 font-mono text-2xl font-medium text-white tabular-nums">
            {activeOrders}
          </p>
        </SpotlightCard>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <SpotlightCard className="p-6 lg:col-span-7">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="flex flex-wrap items-center gap-4 border-b border-white/10 pb-5">
              <div className="relative h-16 w-16 overflow-hidden border border-white/20 bg-[#141417]">
                {form.avatarUrl ? (
                  <img
                    src={form.avatarUrl}
                    alt={form.nickname}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center">
                    <User className="h-6 w-6 text-[#8A8A8E]" />
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <label className="inline-flex min-h-[38px] cursor-pointer items-center gap-2 border border-white/15 bg-[#141417] px-3.5 py-1.5 text-xs font-medium text-[#F5F5F5] transition-colors hover:border-white/45">
                    <Camera className="h-3.5 w-3.5 text-white" />
                    <span>Загрузить фото</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleAvatarUpload}
                      className="hidden"
                    />
                  </label>
                  <span className="text-xs text-[#8A8A8E]">или выберите аватар:</span>
                </div>

                <div className="flex items-center gap-2">
                  {PRESET_AVATARS.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setForm((prev) => ({ ...prev, avatarUrl: preset }))}
                      aria-label={`Выбрать аватар ${idx + 1}`}
                      className={`h-8 w-8 overflow-hidden border transition-all ${
                        form.avatarUrl === preset
                          ? 'border-white scale-105'
                          : 'border-white/15 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={preset} alt="" className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className="block space-y-1.5">
                <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                  Никнейм
                </span>
                <input
                  type="text"
                  value={form.nickname}
                  onChange={(e) => setForm((p) => ({ ...p, nickname: e.target.value }))}
                  placeholder="verlano_member"
                  className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                  Телефон
                </span>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
                  placeholder="+7 (999) 000-00-00"
                  className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 font-mono text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                  Имя
                </span>
                <input
                  type="text"
                  value={form.firstName}
                  onChange={(e) => setForm((p) => ({ ...p, firstName: e.target.value }))}
                  placeholder="Алексей"
                  className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                  Фамилия
                </span>
                <input
                  type="text"
                  value={form.lastName}
                  onChange={(e) => setForm((p) => ({ ...p, lastName: e.target.value }))}
                  placeholder="Волков"
                  className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
                />
              </label>
            </div>

            <label className="block space-y-1.5">
              <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                Адрес доставки
              </span>
              <input
                type="text"
                value={form.address}
                onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
                placeholder="Город, улица, дом, квартира или пункт СДЭК"
                className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
              />
            </label>

            <label className="block space-y-1.5">
              <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#8A8A8E]">
                Комментарий к доставке
              </span>
              <input
                type="text"
                value={form.deliveryNote}
                onChange={(e) => setForm((p) => ({ ...p, deliveryNote: e.target.value }))}
                placeholder="Например: позвонить за 30 минут"
                className="w-full border border-white/15 bg-[#080809] px-3.5 py-2.5 text-sm text-[#F5F5F5] placeholder-[#52525B] outline-none transition-colors focus:border-white/45"
              />
            </label>

            {errorMsg && (
              <p className="border border-white/25 bg-white/[0.05] px-3 py-2 text-xs text-white">
                {errorMsg}
              </p>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <p className="text-xs text-[#8A8A8E]">
                Подставляются в корзину автоматически.
              </p>
              <button
                type="submit"
                disabled={saving}
                className="flex min-h-[44px] items-center gap-2 bg-white px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809] transition-colors hover:bg-white/90 disabled:opacity-60"
              >
                {savedNotice ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                <span>{savedNotice ? 'Сохранено' : saving ? 'Сохранение...' : 'Сохранить'}</span>
              </button>
            </div>
          </form>
        </SpotlightCard>

        <SpotlightCard className="p-6 lg:col-span-5">
          <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-3.5">
            <h3 className="font-display text-2xl font-medium text-[#F5F5F5]">История заказов</h3>
            <span className="font-mono text-xs text-white tabular-nums">{orders.length}</span>
          </div>

          {orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Package className="mb-3 h-7 w-7 text-[#52525B]" />
              <p className="text-sm text-[#F5F5F5]">Заказов пока нет</p>
              <p className="mt-1 text-xs text-[#8A8A8E]">
                Выберите позиции в каталоге, чтобы оформить первый заказ.
              </p>
            </div>
          ) : (
            <div className="max-h-[460px] space-y-3 overflow-y-auto pr-1">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="border border-white/10 bg-[#080809] p-4"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-medium text-[#F5F5F5]">
                      {order.orderNumber}
                    </span>
                    <span className="font-mono text-xs text-white">
                      {ORDER_STATUS_TEXT[order.status]}
                    </span>
                  </div>
                  <div className="mt-2 space-y-1">
                    {order.items.map((item, i) => (
                      <p key={i} className="text-xs text-[#8A8A8E]">
                        {item.name} · {item.size} × {item.quantity}
                      </p>
                    ))}
                  </div>
                  <div className="mt-3 flex items-center justify-between border-t border-white/10 pt-2.5 text-xs">
                    <span className="text-[#8A8A8E]">
                      {new Date(order.createdAt).toLocaleDateString('ru-RU')}
                    </span>
                    <span className="font-mono font-medium text-[#F5F5F5] tabular-nums">
                      {formatPrice(order.totalAmount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </SpotlightCard>
      </div>
    </motion.div>
  );
}
