export type CategoryKey = 'tshirts' | 'pants' | 'ziphoodies';

export type OrderStatus = 'new' | 'confirmed' | 'packing' | 'shipped' | 'delivered';

export type AppSection = 'wheel' | 'order' | 'profile' | 'cart' | 'promocodes' | 'news' | 'admin';

export interface ProductSizeStock {
  size: 'S' | 'M' | 'L' | 'XL';
  stock: number;
}

export interface Product {
  id: string;
  category: CategoryKey;
  name: string;
  subtitle: string;
  description: string;
  material: string;
  fit: string;
  price: number;
  imageUrl: string;
  sizes: ProductSizeStock[];
  featured: boolean;
  createdAt: string;
}

export interface CustomerProfile {
  userId: string;
  nickname: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  deliveryNote: string;
  avatarUrl: string;
  demoSubscribed: boolean;
  updatedAt: string;
}

export interface PromoCode {
  id: string;
  code: string;
  discountPercent: number;
  minOrderAmount: number;
  isPublic: boolean;
  active: boolean;
  description: string;
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  imageUrl: string;
  size: 'S' | 'M' | 'L' | 'XL';
  quantity: number;
  unitPrice: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  items: OrderItem[];
  promoCode: string | null;
  subtotalAmount: number;
  discountAmount: number;
  totalAmount: number;
  customerSnapshot: {
    nickname: string;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    deliveryNote: string;
  };
  status: OrderStatus;
  createdAt: string;
}

export interface NewsPost {
  id: string;
  title: string;
  summary: string;
  date: string;
  tag: string;
}

export interface CategoryMeta {
  title: string;
  subtitle: string;
}

export interface StoreSettings {
  brandName: string;
  channelUsername: string;
  channelUrl: string;
  botUsername: string;
  categories?: Record<CategoryKey, CategoryMeta>;
}

export interface CartEntry {
  productId: string;
  size: 'S' | 'M' | 'L' | 'XL';
  quantity: number;
}

export interface SubscriptionCheckResult {
  subscribed: boolean;
  mode: 'telegram' | 'demo';
  channelUsername: string;
  channelUrl: string;
  botConfigured: boolean;
  message?: string;
}
