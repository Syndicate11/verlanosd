import type {
  CustomerProfile,
  NewsPost,
  Order,
  OrderStatus,
  Product,
  PromoCode,
  StoreSettings,
  SubscriptionCheckResult,
} from '../types/store';

interface TelegramWebApp {
  initData?: string;
  initDataUnsafe?: {
    user?: {
      id?: number;
      username?: string;
      first_name?: string;
      last_name?: string;
    };
  };
  ready?: () => void;
  expand?: () => void;
  disableVerticalSwipes?: () => void;
  setHeaderColor?: (color: string) => void;
  setBackgroundColor?: (color: string) => void;
  openTelegramLink?: (url: string) => void;
  BackButton?: {
    show?: () => void;
    hide?: () => void;
    onClick?: (cb: () => void) => void;
    offClick?: (cb: () => void) => void;
  };
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: TelegramWebApp;
    };
  }
}

export function getTelegramWebApp(): TelegramWebApp | null {
  return window.Telegram?.WebApp ?? null;
}

export function getDemoUserId(): string {
  const key = 'verlano_demo_uid';
  try {
    const existing = window.localStorage.getItem(key);
    if (existing && /^[A-Za-z0-9_-]{4,64}$/.test(existing)) {
      return existing;
    }
    const generated = `demo_${Math.random().toString(36).slice(2, 10)}`;
    window.localStorage.setItem(key, generated);
    return generated;
  } catch {
    return 'demo_guest_01';
  }
}

function buildHeaders(extra?: Record<string, string>): Record<string, string> {
  const tg = getTelegramWebApp();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-demo-user-id': getDemoUserId(),
    ...extra,
  };
  if (tg?.initData) {
    headers['x-telegram-init-data'] = tg.initData;
  }
  return headers;
}

async function requestJson<T>(url: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(url, {
    ...options,
    headers: buildHeaders((options.headers as Record<string, string>) || {}),
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) {
    throw new Error(data.error || `Ошибка запроса (${response.status})`);
  }
  return data;
}

export interface BootstrapResponse {
  profile: CustomerProfile;
  orders: Order[];
  products: Product[];
  publicPromos: PromoCode[];
  newsPosts: NewsPost[];
  settings: StoreSettings;
  subscription: SubscriptionCheckResult;
}

export function fetchBootstrap(): Promise<BootstrapResponse> {
  return requestJson<BootstrapResponse>('/api/bootstrap');
}

export function checkSubscription(): Promise<SubscriptionCheckResult> {
  return requestJson<SubscriptionCheckResult>('/api/telegram/check-subscription', {
    method: 'POST',
  });
}

export function setDemoSubscription(subscribed: boolean): Promise<SubscriptionCheckResult> {
  return requestJson<SubscriptionCheckResult>('/api/telegram/demo-subscribe', {
    method: 'POST',
    body: JSON.stringify({ subscribed }),
  });
}

export function updateProfile(payload: Partial<CustomerProfile>): Promise<{ profile: CustomerProfile }> {
  return requestJson<{ profile: CustomerProfile }>('/api/profile', {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export function validatePromoCode(code: string, subtotal: number): Promise<{ promo: PromoCode }> {
  return requestJson<{ promo: PromoCode }>('/api/promocodes/validate', {
    method: 'POST',
    body: JSON.stringify({ code, subtotal }),
  });
}

export function createOrder(payload: {
  items: Array<{ productId: string; size: 'S' | 'M' | 'L' | 'XL'; quantity: number }>;
  promoCode: string | null;
  customer: {
    nickname: string;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    deliveryNote: string;
  };
}): Promise<{ order: Order }> {
  return requestJson<{ order: Order }>('/api/orders', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function fetchAdminStatus(): Promise<{
  envConfigured: boolean;
  claimed: boolean;
  allowedIdsConfigured: boolean;
}> {
  return requestJson('/api/admin/status');
}

export function setupAdminAccount(adminId: string, password: string): Promise<{ token: string; adminId: string }> {
  return requestJson('/api/admin/setup', {
    method: 'POST',
    body: JSON.stringify({ adminId, password }),
  });
}

export function loginAdmin(adminId: string, password: string): Promise<{ token: string; adminId: string }> {
  return requestJson('/api/admin/login', {
    method: 'POST',
    body: JSON.stringify({ adminId, password }),
  });
}

export function fetchAdminOverview(token: string): Promise<{
  orders: Order[];
  products: Product[];
  promoCodes: PromoCode[];
  settings: StoreSettings;
  botConfigured: boolean;
  channelEnvConfigured: boolean;
}> {
  return requestJson('/api/admin/overview', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function adminUpdateOrderStatus(
  token: string,
  orderId: string,
  status: OrderStatus
): Promise<{ ok: boolean; status: OrderStatus }> {
  return requestJson(`/api/admin/orders/${encodeURIComponent(orderId)}/status`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ status }),
  });
}

export function adminCreateProduct(
  token: string,
  payload: Record<string, unknown>
): Promise<{ product: Product }> {
  return requestJson('/api/admin/products', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function adminUpdateProduct(
  token: string,
  productId: string,
  payload: Record<string, unknown>
): Promise<{ product: Product }> {
  return requestJson(`/api/admin/products/${encodeURIComponent(productId)}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function adminDeleteProduct(token: string, productId: string): Promise<{ ok: boolean }> {
  return requestJson(`/api/admin/products/${encodeURIComponent(productId)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function adminCreatePromo(
  token: string,
  payload: Record<string, unknown>
): Promise<{ promo: PromoCode }> {
  return requestJson('/api/admin/promocodes', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function adminTogglePromo(
  token: string,
  promoId: string,
  payload: { active?: boolean; isPublic?: boolean }
): Promise<{ ok: boolean }> {
  return requestJson(`/api/admin/promocodes/${encodeURIComponent(promoId)}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function adminDeletePromo(token: string, promoId: string): Promise<{ ok: boolean }> {
  return requestJson(`/api/admin/promocodes/${encodeURIComponent(promoId)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function adminUpdateSettings(
  token: string,
  payload: Partial<StoreSettings>
): Promise<{ settings: StoreSettings }> {
  return requestJson('/api/admin/settings', {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function formatPrice(amount: number): string {
  return `${new Intl.NumberFormat('ru-RU').format(Math.round(amount))} ₽`;
}

export const ORDER_STATUS_TEXT: Record<OrderStatus, string> = {
  new: 'Новый',
  confirmed: 'Подтверждён',
  packing: 'В сборке',
  shipped: 'Отправлен',
  delivered: 'Доставлен',
};
