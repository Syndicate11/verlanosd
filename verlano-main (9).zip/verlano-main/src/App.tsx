import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, ShoppingBag } from 'lucide-react';
import { SplashScreen } from './components/SplashScreen';
import { SubscriptionGate } from './components/SubscriptionGate';
import { WheelMenu } from './components/WheelMenu';
import { OrderSection } from './components/OrderSection';
import { ProfileSection } from './components/ProfileSection';
import { CartSection } from './components/CartSection';
import { PromocodesSection } from './components/PromocodesSection';
import { NewsSection } from './components/NewsSection';
import { AdminSection } from './components/AdminSection';
import {
  checkSubscription,
  createOrder,
  fetchBootstrap,
  getTelegramWebApp,
  setDemoSubscription,
  updateProfile,
} from './lib/api';
import type {
  AppSection,
  CartEntry,
  CategoryKey,
  CustomerProfile,
  NewsPost,
  Order,
  Product,
  PromoCode,
  StoreSettings,
  SubscriptionCheckResult,
} from './types/store';

interface NavRoute {
  section: AppSection;
  category?: CategoryKey | null;
  productId?: string | null;
}

const SECTION_TITLES: Record<AppSection, string> = {
  wheel: 'Меню',
  order: 'Заказать',
  profile: 'Профиль',
  cart: 'Корзина',
  promocodes: 'Промокоды',
  news: 'Новости',
  admin: 'Админ-панель',
};

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [navStack, setNavStack] = useState<NavRoute[]>([{ section: 'wheel' }]);
  const [wheelIndex, setWheelIndex] = useState(0);
  const currentRoute = navStack[navStack.length - 1];
  const section = currentRoute.section;
  const [profile, setProfile] = useState<CustomerProfile>({
    userId: '',
    nickname: 'verlano_guest',
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    deliveryNote: '',
    avatarUrl: '',
    demoSubscribed: false,
    updatedAt: '',
  });
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [publicPromos, setPublicPromos] = useState<PromoCode[]>([]);
  const [newsPosts, setNewsPosts] = useState<NewsPost[]>([]);
  const [settings, setSettings] = useState<StoreSettings>({
    brandName: 'Verlano',
    channelUsername: '@verlano_news',
    channelUrl: 'https://t.me/verlano_news',
    botUsername: '@verlano_shop_bot',
  });
  const [subscription, setSubscription] = useState<SubscriptionCheckResult>({
    subscribed: false,
    mode: 'demo',
    channelUsername: '@verlano_news',
    channelUrl: 'https://t.me/verlano_news',
    botConfigured: false,
  });

  const [cart, setCart] = useState<CartEntry[]>(() => {
    try {
      const saved = window.localStorage.getItem('verlano_cart');
      return saved ? (JSON.parse(saved) as CartEntry[]) : [];
    } catch {
      return [];
    }
  });
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem('verlano_cart', JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }, [cart]);

  const loadAppData = useCallback(async () => {
    setLoadError('');
    try {
      const data = await fetchBootstrap();
      setProfile(data.profile);
      setOrders(data.orders);
      setProducts(data.products);
      setPublicPromos(data.publicPromos);
      setNewsPosts(data.newsPosts);
      setSettings(data.settings);
      setSubscription(data.subscription);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Не удалось загрузить магазин Verlano');
    } finally {
      setLoading(false);
    }
  }, []);

  const pushRoute = useCallback((next: NavRoute) => {
    setNavStack((prev) => {
      const top = prev[prev.length - 1];
      if (
        top &&
        top.section === next.section &&
        (top.category ?? null) === (next.category ?? null) &&
        (top.productId ?? null) === (next.productId ?? null)
      ) {
        return prev;
      }
      return [...prev, next];
    });
  }, []);

  const goBackOneStep = useCallback(() => {
    setNavStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  }, []);

  const resetToMenu = useCallback(() => {
    setNavStack([{ section: 'wheel' }]);
  }, []);

  useEffect(() => {
    const tg = getTelegramWebApp();
    tg?.ready?.();
    tg?.expand?.();
    tg?.disableVerticalSwipes?.();
    tg?.setHeaderColor?.('#080809');
    tg?.setBackgroundColor?.('#080809');

    void loadAppData();
    const timer = window.setTimeout(() => setShowSplash(false), 1250);
    return () => window.clearTimeout(timer);
  }, [loadAppData]);

  useEffect(() => {
    const tg = getTelegramWebApp();
    const backBtn = tg?.BackButton;
    if (!backBtn) return;

    if (navStack.length > 1) {
      backBtn.show?.();
      backBtn.onClick?.(goBackOneStep);
    } else {
      backBtn.hide?.();
    }

    return () => {
      backBtn.offClick?.(goBackOneStep);
    };
  }, [navStack.length, goBackOneStep]);

  const handleCheckSubscription = async () => {
    const res = await checkSubscription();
    setSubscription(res);
  };

  const handleDemoConfirm = async () => {
    const res = await setDemoSubscription(true);
    setSubscription(res);
  };

  const handleAddToCart = (productId: string, size: 'S' | 'M' | 'L' | 'XL') => {
    setCart((prev) => {
      const existing = prev.find((i) => i.productId === productId && i.size === size);
      if (existing) {
        return prev.map((i) =>
          i.productId === productId && i.size === size
            ? { ...i, quantity: i.quantity + 1 }
            : i
        );
      }
      return [...prev, { productId, size, quantity: 1 }];
    });
  };

  const handleUpdateCartQuantity = (
    productId: string,
    size: 'S' | 'M' | 'L' | 'XL',
    delta: number
  ) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.productId === productId && item.size === size
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveFromCart = (productId: string, size: 'S' | 'M' | 'L' | 'XL') => {
    setCart((prev) => prev.filter((item) => !(item.productId === productId && item.size === size)));
  };

  const handleSaveProfile = async (payload: Partial<CustomerProfile>) => {
    const { profile: updated } = await updateProfile(payload);
    setProfile(updated);
  };

  const handleSubmitOrder = async (customer: {
    nickname: string;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    deliveryNote: string;
  }): Promise<Order> => {
    const { order } = await createOrder({
      items: cart,
      promoCode: appliedPromo?.code || null,
      customer,
    });
    setCart([]);
    setAppliedPromo(null);
    await loadAppData();
    return order;
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => {
    const product = products.find((p) => p.id === item.productId);
    return sum + (product ? product.price * item.quantity : 0);
  }, 0);

  return (
    <div className="min-h-[100dvh] bg-[#080809] text-[#F5F5F5]">
      <AnimatePresence>{showSplash && <SplashScreen />}</AnimatePresence>

      {!showSplash && loading && (
        <div className="flex min-h-[100dvh] items-center justify-center px-4">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-[#8A8A8E]">
            Verlano · Загрузка
          </p>
        </div>
      )}

      {!showSplash && !loading && loadError && (
        <div className="flex min-h-[100dvh] flex-col items-center justify-center gap-4 px-4 text-center">
          <p className="text-sm text-white/80">{loadError}</p>
          <button
            type="button"
            onClick={() => void loadAppData()}
            className="bg-white px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#080809]"
          >
            Повторить
          </button>
        </div>
      )}

      {!showSplash && !loading && !loadError && !subscription.subscribed && (
        <SubscriptionGate
          subscription={subscription}
          onCheck={handleCheckSubscription}
          onDemoConfirm={handleDemoConfirm}
        />
      )}

      {!showSplash && !loading && !loadError && subscription.subscribed && (
        <>
          {section === 'wheel' ? (
            <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-[#080809]/92 backdrop-blur-md">
              <div className="mx-auto flex h-14 max-w-6xl items-center justify-center px-4">
                <span className="font-display text-2xl font-medium tracking-[0.28em] text-white whitespace-nowrap">
                  VERLANO
                </span>
              </div>
            </header>
          ) : (
            <header className="sticky top-0 z-40 border-b border-white/[0.08] bg-[#080809]/92 backdrop-blur-md">
              <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={goBackOneStep}
                    className="flex min-h-[38px] items-center gap-1.5 border border-white/[0.14] bg-[#0E0E10] px-3 py-1.5 text-xs font-medium text-white transition-colors hover:border-white/40 whitespace-nowrap shrink-0"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    <span>Назад</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={resetToMenu}
                  className="truncate font-mono text-[11px] uppercase tracking-[0.18em] text-[#8A8A8E] transition-colors hover:text-white"
                >
                  {`VERLANO · ${SECTION_TITLES[section]}`}
                </button>

                <button
                  type="button"
                  onClick={() => pushRoute({ section: 'cart' })}
                  className="flex min-h-[38px] items-center gap-2 bg-white px-3.5 py-1.5 text-xs font-semibold text-[#080809] transition-colors hover:bg-white/85 active:scale-[0.98] whitespace-nowrap shrink-0"
                >
                  <ShoppingBag className="h-3.5 w-3.5" />
                  <span className="tabular-nums">
                    {cartCount > 0 ? `Корзина (${cartCount})` : 'Корзина'}
                  </span>
                </button>
              </div>
            </header>
          )}

          <main className={section === 'wheel' ? 'mx-auto max-w-6xl' : 'mx-auto max-w-6xl px-4 pb-16 pt-6 sm:px-6'}>
            <AnimatePresence mode="wait">
              {section === 'wheel' && (
                <motion.div
                  key="wheel"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                >
                  <WheelMenu
                    onSelectSection={(target) => pushRoute({ section: target })}
                    cartCount={cartCount}
                    cartSubtotal={cartSubtotal}
                    profile={profile}
                    newsPosts={newsPosts}
                    publicPromosCount={publicPromos.length}
                    activeIndex={wheelIndex}
                    onChangeIndex={setWheelIndex}
                  />
                </motion.div>
              )}

              {section === 'order' && (
                <OrderSection
                  products={products}
                  cart={cart}
                  settings={settings}
                  selectedCategory={currentRoute.category ?? null}
                  selectedProductId={currentRoute.productId ?? null}
                  onSelectCategory={(cat) => pushRoute({ section: 'order', category: cat })}
                  onSelectProduct={(productId) =>
                    pushRoute({
                      section: 'order',
                      category: currentRoute.category ?? null,
                      productId,
                    })
                  }
                  onBackStep={goBackOneStep}
                  onAddToCart={handleAddToCart}
                  onUpdateCartQuantity={handleUpdateCartQuantity}
                  onRemoveFromCart={handleRemoveFromCart}
                  onGoToCart={() => pushRoute({ section: 'cart' })}
                />
              )}

              {section === 'profile' && (
                <ProfileSection
                  profile={profile}
                  orders={orders}
                  onSaveProfile={handleSaveProfile}
                />
              )}

              {section === 'cart' && (
                <CartSection
                  cart={cart}
                  products={products}
                  profile={profile}
                  appliedPromo={appliedPromo}
                  onApplyPromo={setAppliedPromo}
                  onUpdateQuantity={handleUpdateCartQuantity}
                  onRemoveItem={handleRemoveFromCart}
                  onSubmitOrder={handleSubmitOrder}
                  onGoToCatalog={() => pushRoute({ section: 'order' })}
                />
              )}

              {section === 'promocodes' && (
                <PromocodesSection
                  publicPromos={publicPromos}
                  appliedPromo={appliedPromo}
                  cartSubtotal={cartSubtotal}
                  onApplyPromo={(promo) => setAppliedPromo(promo)}
                  onGoToCart={() => pushRoute({ section: 'cart' })}
                />
              )}

              {section === 'news' && (
                <NewsSection
                  settings={settings}
                  newsPosts={newsPosts}
                  subscription={subscription}
                  onRecheckSubscription={handleCheckSubscription}
                />
              )}

              {section === 'admin' && (
                <AdminSection
                  onDataChanged={loadAppData}
                  currentUserId={profile.userId}
                />
              )}
            </AnimatePresence>
          </main>
        </>
      )}
    </div>
  );
}
