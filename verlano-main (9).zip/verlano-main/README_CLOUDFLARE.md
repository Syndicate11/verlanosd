# Инструкция по запуску Verlano через `.bat` и бесплатный Cloudflare Tunnel

## 1. Что нужно установить на ПК (Windows)
1. **Node.js 22+** (или 20+): скачать с [nodejs.org](https://nodejs.org/).
2. **Cloudflare Tunnel (`cloudflared`)**:
   - Откройте PowerShell или CMD и выполните:
     ```bat
     winget install --id Cloudflare.cloudflared
     ```
   - Либо скачайте `cloudflared-windows-amd64.exe` с GitHub Cloudflare, переименуйте в `cloudflared.exe` и положите рядом с `start_verlano.bat`.

## 2. Настройка `.env` перед первым тестом
1. Скопируйте `.env.example` в `.env` (при первом запуске `start_verlano.bat` сделает это автоматически).
2. Откройте `.env` и заполните:
   - `TELEGRAM_BOT_TOKEN=` — токен вашего бота от `@BotFather` (если оставить пустым, магазин будет работать в браузерном демо-режиме).
   - `TELEGRAM_CHANNEL_ID=` — `@username` вашего новостного канала (например, `@verlano_news`). **Важно:** добавьте бота администратором в этот канал, чтобы работала проверка подписки `getChatMember`.
   - `TELEGRAM_CHANNEL_URL=` — публичная ссылка на канал (например, `https://t.me/verlano_news`).
   - `ADMIN_TELEGRAM_IDS=` — ваш числовой Telegram ID (можно узнать в `@userinfobot`), чтобы получать уведомления о заказах и входить в админку.
   - `ADMIN_PASSWORD=Verlanoqwe` — ваш пароль от админ-панели (либо оставьте пустым и задайте пароль прямо внутри приложения при первом открытии вкладки «Админ-панель»).

## 3. Запуск через `start_verlano.bat`
1. Дважды нажмите на файл **`start_verlano.bat`** в корне проекта.
2. Скрипт автоматически:
   - установит зависимости (если `node_modules` ещё нет),
   - соберёт интерфейс (`npm run build`),
   - запустит Express-сервер в отдельном окне на порту `3000`,
   - поднимет бесплатный туннель `cloudflared tunnel --url http://localhost:3000`.
3. В окне Cloudflare появится временная HTTPS-ссылка вида:
   `https://random-words-here.trycloudflare.com`

## 4. Подключение Mini App в `@BotFather`
1. Откройте `@BotFather` в Telegram → выберите вашего бота → **Bot Settings** → **Menu Button** → **Configure menu button**.
2. Вставьте полученный адрес `https://....trycloudflare.com` и задайте название кнопки, например `Магазин Verlano`.
3. Либо создайте команду `/newapp` и привяжите ту же ссылку.
4. Откройте бота в Telegram и запустите Mini App!

> **Совет:** У бесплатного Quick Tunnel адрес `*.trycloudflare.com` меняется при каждом перезапуске `cloudflared`. При следующем запуске `.bat` просто обновите URL в `@BotFather`.
